import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { HomeIcon, ForYouIcon, UserIcon } from './icons';

const navLinks = [
  { to: '/dashboard', text: 'Início', icon: <HomeIcon /> },
  { to: '/foryou', text: 'Para Você', icon: <ForYouIcon /> },
  { to: '/profile', text: 'Meu Perfil', icon: <UserIcon /> },
];

const BuyerSidebar: React.FC = () => {
  const location = useLocation();

  return (
    <aside className="hidden md:block w-64 flex-shrink-0 fixed h-full">
      <div className="bg-slate-800 p-4 h-full border-r border-slate-700">
        <nav className="space-y-2 mt-16 pt-4">
          {navLinks.map(link => (
            <Link
              key={link.to}
              to={link.to}
              className={`flex items-center space-x-3 p-3 rounded-md font-medium text-sm transition-colors ${
                location.pathname.startsWith(link.to)
                  ? 'bg-sky-500/20 text-sky-300'
                  : 'text-slate-300 hover:bg-slate-700'
              }`}
            >
              {link.icon}
              <span>{link.text}</span>
            </Link>
          ))}
        </nav>
      </div>
    </aside>
  );
};

export default BuyerSidebar;
