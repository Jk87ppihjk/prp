import React from 'react';

interface CardProps {
  children: React.ReactNode;
  className?: string;
  title?: string;
  noPadding?: boolean;
  // FIX: Add style prop to allow passing inline styles for animations.
  style?: React.CSSProperties;
}

const Card: React.FC<CardProps> = ({ children, className = '', title, noPadding = false, style }) => {
  return (
    <div className={`bg-slate-800 shadow-lg rounded-lg overflow-hidden border border-slate-700 ${className}`} style={style}>
      {title && (
        <div className="px-4 py-5 sm:px-6 border-b border-slate-700">
          <h3 className="text-lg leading-6 font-semibold text-sky-400">{title}</h3>
        </div>
      )}
      <div className={!noPadding ? "p-4 sm:p-6" : ""}>
        {children}
      </div>
    </div>
  );
};

export default Card;