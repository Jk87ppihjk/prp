import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import Button from './Button';
import { useCart } from '../hooks/useCart';
import { ShoppingCartIcon } from './icons/ShoppingCartIcon';

const Header: React.FC = () => {
  const { isAuthenticated, user, logout, isBuyer, isSeller } = useAuth();
  const { cartItems } = useCart();
  
  const itemCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);

  const getProfileLink = () => {
    if (isSeller) return '/seller/profile';
    return '/';
  }

  return (
    <header className="bg-slate-800 shadow-md sticky top-0 z-40 border-b border-slate-700/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex-shrink-0">
            <Link to="/dashboard" className="text-2xl font-bold text-sky-400 hover:text-sky-300 transition-colors">
              Prudente
            </Link>
          </div>
          <div className="flex items-center space-x-4">
            {isAuthenticated && user ? (
              <>
                <span className="text-sm font-medium text-slate-300 hidden sm:block">
                  Olá, {user.fullName.split(' ')[0]}
                </span>

                {isBuyer && (
                  <Link to="/cart" className="relative p-2 text-slate-300 hover:text-white transition-colors">
                    <ShoppingCartIcon />
                    {itemCount > 0 && (
                      <span className="absolute -top-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full bg-red-500 text-xs font-bold text-white">
                        {itemCount}
                      </span>
                    )}
                  </Link>
                )}

                {isSeller && (
                   <Link to={getProfileLink()}>
                    <Button variant="secondary" className="w-auto !py-1.5">Meu Perfil</Button>
                  </Link>
                )}
                <Button onClick={logout} variant="secondary" className="w-auto !py-1.5 bg-slate-700 hover:bg-slate-600">Sair</Button>
              </>
            ) : (
              <>
                <Link to="/login">
                  <Button variant="secondary" className="w-auto !py-1.5 bg-slate-700 hover:bg-slate-600">Login</Button>
                </Link>
                <Link to="/register">
                  <Button variant="primary" className="w-auto !py-1.5">Cadastrar</Button>
                </Link>
              </>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;