import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import ApprovalIcon from './icons/ApprovalIcon';
import CategoryIcon from './icons/CategoryIcon';
import LocationIcon from './icons/LocationIcon';

const AdminSidebar: React.FC = () => {
  const location = useLocation();

  const navLinks = [
    { to: '/admin/approvals', text: 'Aprovar Produtos', icon: <ApprovalIcon /> },
    { to: '/admin/categories', text: 'Categorias', icon: <CategoryIcon /> },
    { to: '/admin/locations', text: 'Localidades', icon: <LocationIcon /> },
  ];

  return (
    <aside className="md:w-64 flex-shrink-0">
      <div className="bg-slate-800 p-4 rounded-lg shadow-lg border border-slate-700">
        <h2 className="text-xl font-bold mb-4 text-white">Painel Admin</h2>
        <nav className="space-y-2">
          {navLinks.map(link => (
            <Link
              key={link.to}
              to={link.to}
              className={`flex items-center space-x-3 p-3 rounded-md font-medium text-sm transition-colors ${
                location.pathname.startsWith(link.to)
                  ? 'bg-sky-500/20 text-sky-300'
                  : 'text-slate-300 hover:bg-slate-700'
              }`}
            >
              {link.icon}
              <span>{link.text}</span>
            </Link>
          ))}
        </nav>
      </div>
    </aside>
  );
};

export default AdminSidebar;