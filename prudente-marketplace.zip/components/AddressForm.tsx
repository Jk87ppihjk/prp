import React, { useState, useEffect } from 'react';
import { Address, City, Neighborhood } from '../types';
import { api } from '../services/mockApi';
import Input from './Input';
import Select from './Select';
import Button from './Button';

interface AddressFormProps {
  initialAddress: Partial<Address>;
  onSave: (address: Address) => void;
  title: string;
}

const AddressForm: React.FC<AddressFormProps> = ({ initialAddress, onSave, title }) => {
  const [address, setAddress] = useState<Partial<Address>>(initialAddress || {});
  const [cities, setCities] = useState<City[]>([]);
  const [neighborhoods, setNeighborhoods] = useState<Neighborhood[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    api.getCities().then(setCities);
  }, []);

  useEffect(() => {
    if (address.cityId) {
      api.getNeighborhoodsByCity(address.cityId).then(setNeighborhoods);
    } else {
      setNeighborhoods([]);
    }
  }, [address.cityId]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setAddress(prev => ({ ...prev, [name]: value }));
    if (name === 'cityId') {
      setAddress(prev => ({ ...prev, neighborhoodId: '' }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
        // Basic validation
        if(address.street && address.number && address.neighborhoodId && address.cityId && address.state && address.zipCode) {
            await onSave(address as Address);
            alert('Endereço salvo com sucesso!');
        } else {
            throw new Error("Por favor, preencha todos os campos obrigatórios.");
        }
    } catch (error: any) {
        alert(`Erro ao salvar: ${error.message}`);
    } finally {
        setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <h2 className="text-xl font-semibold text-white">{title}</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Input label="Rua/Avenida" name="street" value={address.street || ''} onChange={handleChange} required />
        <Input label="Número" name="number" value={address.number || ''} onChange={handleChange} required />
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Input label="Complemento (Opcional)" name="complement" value={address.complement || ''} onChange={handleChange} />
        <Input label="CEP" name="zipCode" value={address.zipCode || ''} onChange={handleChange} required />
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Input label="Estado" name="state" value={address.state || ''} onChange={handleChange} required />
        <Select label="Cidade" name="cityId" value={address.cityId || ''} onChange={handleChange} required>
            <option value="">Selecione a cidade</option>
            {cities.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
        </Select>
        <Select label="Bairro" name="neighborhoodId" value={address.neighborhoodId || ''} onChange={handleChange} required disabled={!address.cityId}>
            <option value="">Selecione o bairro</option>
            {neighborhoods.map(n => <option key={n.id} value={n.id}>{n.name}</option>)}
        </Select>
      </div>
      <div className="pt-2">
        <Button type="submit" isLoading={loading}>Salvar Endereço</Button>
      </div>
    </form>
  );
};

export default AddressForm;