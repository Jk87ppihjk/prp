import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { HomeIcon, ForYouIcon, UserIcon } from './icons';

const navLinks = [
    { to: '/dashboard', text: 'Início', icon: <HomeIcon /> },
    { to: '/foryou', text: 'Para Você', icon: <ForYouIcon /> },
    { to: '/profile', text: 'Perfil', icon: <UserIcon /> },
];

const BottomNavBar: React.FC = () => {
    const location = useLocation();

    return (
        <div className="md:hidden fixed bottom-0 left-0 right-0 h-16 bg-slate-800 border-t border-slate-700 shadow-lg z-50">
            <nav className="flex justify-around items-center h-full">
                {navLinks.map(link => (
                    <Link
                        key={link.to}
                        to={link.to}
                        className={`flex flex-col items-center justify-center w-full h-full transition-colors ${
                            location.pathname.startsWith(link.to)
                            ? 'text-sky-400'
                            : 'text-slate-400 hover:text-sky-300'
                        }`}
                    >
                        <div className="h-6 w-6">{link.icon}</div>
                        <span className="text-xs mt-1">{link.text}</span>
                    </Link>
                ))}
            </nav>
        </div>
    );
};

export default BottomNavBar;
