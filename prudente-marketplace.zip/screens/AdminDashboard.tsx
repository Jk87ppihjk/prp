
import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import AdminSidebar from '../components/AdminSidebar';
import AdminProductApproval from './admin/AdminProductApproval';
import AdminCategoryManagement from './admin/AdminCategoryManagement';
import AdminLocationManagement from './admin/AdminLocationManagement';

const AdminDashboard: React.FC = () => {
  return (
    <div className="flex flex-col md:flex-row gap-8">
      <AdminSidebar />
      <main className="flex-grow">
        <Routes>
          <Route path="/" element={<Navigate to="approvals" replace />} />
          <Route path="approvals" element={<AdminProductApproval />} />
          <Route path="categories" element={<AdminCategoryManagement />} />
          <Route path="locations" element={<AdminLocationManagement />} />
          <Route path="*" element={<div>Página não encontrada</div>} />
        </Routes>
      </main>
    </div>
  );
};

export default AdminDashboard;
