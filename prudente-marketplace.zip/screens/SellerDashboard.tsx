import React, { useState, useEffect } from 'react';
import { Routes, Route, Link, useLocation } from 'react-router-dom';
import ProductManagement from './seller/ProductManagement';
import StoreSetup from './seller/StoreSetup';
import SellerProfile from './seller/SellerProfile';
import OrderManagement from './seller/OrderManagement';
import { StoreIcon, ProductIcon, UserIcon, ApprovalIcon, HamburgerIcon, CloseIcon, VideoIcon } from '../components/icons';
import SellerFyManagement from './seller/SellerFyManagement';

const SellerDashboard: React.FC = () => {
  const location = useLocation();
  const [isMenuOpen, setMenuOpen] = useState(false);

  const navLinks = [
    { to: '/seller/store', text: 'Minha Loja', icon: <StoreIcon /> },
    { to: '/seller/products', text: 'Produtos', icon: <ProductIcon /> },
    { to: '/seller/orders', text: 'Pedidos Recebidos', icon: <ApprovalIcon /> },
    { to: '/seller/fy', text: 'Vídeos (FY)', icon: <VideoIcon /> },
    { to: '/seller/profile', text: 'Meus Dados', icon: <UserIcon /> },
  ];
  
  // Close menu on route change on mobile
  useEffect(() => {
    if (isMenuOpen) {
      setMenuOpen(false);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [location.pathname]);

  // Prevent body scroll when mobile menu is open
  useEffect(() => {
    if (isMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'auto';
    }
    return () => {
      document.body.style.overflow = 'auto'; // Cleanup on unmount
    };
  }, [isMenuOpen]);

  return (
    <div className="flex bg-slate-900 text-slate-200 min-h-screen">
      {/* Sidebar */}
      <aside
        className={`fixed inset-y-0 left-0 z-50 w-64 bg-slate-800 p-4 transform transition-transform duration-300 ease-in-out md:relative md:translate-x-0 md:border-r md:border-slate-700 ${
          isMenuOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
        aria-label="Sidebar"
      >
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-bold text-white">Painel do Lojista</h2>
          <button className="md:hidden p-1" onClick={() => setMenuOpen(false)} aria-label="Close menu">
            <CloseIcon />
          </button>
        </div>
        <nav className="space-y-2">
          {navLinks.map(link => (
            <Link
              key={link.to}
              to={link.to}
              className={`flex items-center space-x-3 p-3 rounded-md font-medium text-sm transition-colors ${
                location.pathname.startsWith(link.to)
                  ? 'bg-sky-500/20 text-sky-300'
                  : 'text-slate-300 hover:bg-slate-700'
              }`}
            >
              {link.icon}
              <span>{link.text}</span>
            </Link>
          ))}
        </nav>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col w-full">
        {/* Mobile Header */}
        <header className="md:hidden sticky top-0 bg-slate-800 z-30 flex items-center justify-between p-4 border-b border-slate-700">
          <h1 className="text-lg font-semibold text-white">
            {navLinks.find(l => location.pathname.startsWith(l.to))?.text || 'Painel do Lojista'}
          </h1>
          <button onClick={() => setMenuOpen(true)} aria-label="Open menu">
            <HamburgerIcon />
          </button>
        </header>

        <main className="flex-grow p-4 sm:p-6 md:p-8">
          <Routes>
            <Route path="store" element={<StoreSetup />} />
            <Route path="products" element={<ProductManagement />} />
            <Route path="orders" element={<OrderManagement />} />
            <Route path="fy" element={<SellerFyManagement />} />
            <Route path="profile" element={<SellerProfile />} />
            <Route index element={
              <div className="bg-slate-800 p-6 rounded-lg shadow-lg border border-slate-700">
                  <h2 className="text-2xl font-bold text-white">Bem-vindo, Lojista!</h2>
                  <p className="mt-2 text-slate-400">Use o menu ao lado para gerenciar sua loja e seus produtos.</p>
              </div>
            } />
          </Routes>
        </main>
      </div>

      {/* Overlay for when menu is open on mobile */}
      {isMenuOpen && (
        <div 
          className="md:hidden fixed inset-0 bg-black/60 z-40"
          onClick={() => setMenuOpen(false)}
          aria-hidden="true"
        ></div>
      )}
    </div>
  );
};

export default SellerDashboard;