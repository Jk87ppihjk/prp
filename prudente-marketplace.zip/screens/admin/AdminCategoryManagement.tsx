import React, { useState, useEffect } from 'react';
import { Category, Subcategory, Attribute } from '../../types';
import { AttributeType } from '../../constants';
import { api } from '../../services/mockApi';
import Card from '../../components/Card';
import Input from '../../components/Input';
import Button from '../../components/Button';
import Select from '../../components/Select';

const AdminCategoryManagement: React.FC = () => {
  const [categories, setCategories] = useState<Category[]>([]);
  const [newCategoryName, setNewCategoryName] = useState('');
  const [selectedCategoryId, setSelectedCategoryId] = useState<string | null>(null);
  const [newSubcategoryName, setNewSubcategoryName] = useState('');
  
  const [selectedSubcategoryId, setSelectedSubcategoryId] = useState<string | null>(null);
  const [newAttribute, setNewAttribute] = useState({ name: '', type: AttributeType.TEXT, options: '', required: false });
  
  const fetchCategories = async () => {
    const data = await api.getCategories();
    setCategories(data);
  };

  useEffect(() => {
    fetchCategories();
  }, []);

  const handleAddCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newCategoryName) {
      await api.addCategory(newCategoryName);
      setNewCategoryName('');
      fetchCategories();
    }
  };
  
  const handleAddSubcategory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newSubcategoryName && selectedCategoryId) {
      await api.addSubcategory(selectedCategoryId, newSubcategoryName);
      setNewSubcategoryName('');
      fetchCategories();
    }
  };

  const handleAddAttribute = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newAttribute.name && selectedCategoryId && selectedSubcategoryId) {
      await api.addAttribute(selectedCategoryId, selectedSubcategoryId, {
        ...newAttribute,
        options: newAttribute.type === AttributeType.LIST ? newAttribute.options.split(',').map(s => s.trim()) : undefined,
      });
      setNewAttribute({ name: '', type: AttributeType.TEXT, options: '', required: false });
      fetchCategories();
    }
  }
  
  const selectedCategory = categories.find(c => c.id === selectedCategoryId);
  const selectedSubcategory = selectedCategory?.subcategories.find(s => s.id === selectedSubcategoryId);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <Card title="Criar Nova Categoria" className="lg:col-span-1">
        <form onSubmit={handleAddCategory} className="space-y-4">
          <Input label="Nome da Categoria" name="newCategory" value={newCategoryName} onChange={e => setNewCategoryName(e.target.value)} required/>
          <Button type="submit">Adicionar Categoria</Button>
        </form>
      </Card>
      
      <Card title="Gerenciar Subcategorias e Atributos" className="lg:col-span-2">
        <div className="space-y-4">
          <Select label="Selecione uma Categoria" name="category" onChange={e => { setSelectedCategoryId(e.target.value); setSelectedSubcategoryId(null); }}>
            <option value="">-- Selecione --</option>
            {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
          </Select>
          
          {selectedCategoryId && (
            <>
              <form onSubmit={handleAddSubcategory} className="space-y-2 p-4 border border-slate-700 rounded-md bg-slate-900/50">
                <h4 className="font-semibold text-white">Adicionar Subcategoria</h4>
                <Input label="Nome da Subcategoria" name="newSubcategory" value={newSubcategoryName} onChange={e => setNewSubcategoryName(e.target.value)} required/>
                <Button type="submit">Adicionar Subcategoria</Button>
              </form>

              <Select label="Selecione uma Subcategoria para adicionar atributos" name="subcategory" onChange={e => setSelectedSubcategoryId(e.target.value)}>
                <option value="">-- Selecione --</option>
                {selectedCategory?.subcategories.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
              </Select>
            </>
          )}

          {selectedSubcategoryId && (
            <form onSubmit={handleAddAttribute} className="space-y-4 p-4 border border-slate-700 rounded-md bg-slate-900/50">
                <h4 className="font-semibold text-white">Adicionar Atributo à: <span className="text-teal-400">{selectedSubcategory?.name}</span></h4>
                <Input label="Nome do Atributo" name="attrName" value={newAttribute.name} onChange={e => setNewAttribute({...newAttribute, name: e.target.value})} required/>
                <Select label="Tipo do Atributo" name="attrType" value={newAttribute.type} onChange={e => setNewAttribute({...newAttribute, type: e.target.value as AttributeType})}>
                    {Object.values(AttributeType).map(type => <option key={type} value={type}>{type}</option>)}
                </Select>
                {newAttribute.type === AttributeType.LIST && (
                    <Input label="Opções (separadas por vírgula)" name="attrOptions" value={newAttribute.options} onChange={e => setNewAttribute({...newAttribute, options: e.target.value})}/>
                )}
                <div className="flex items-center">
                    <input id="attrRequired" type="checkbox" checked={newAttribute.required} onChange={e => setNewAttribute({...newAttribute, required: e.target.checked})} className="h-4 w-4 text-sky-500 focus:ring-sky-400 border-slate-600 rounded bg-slate-700"/>
                    <label htmlFor="attrRequired" className="ml-2 block text-sm text-slate-300">Obrigatório</label>
                </div>
                <Button type="submit">Adicionar Atributo</Button>
            </form>
          )}
        </div>
      </Card>
      
      <Card title="Estrutura Atual" className="lg:col-span-3">
        <ul className="space-y-4">
          {categories.map(cat => (
            <li key={cat.id} className="p-2 border-b border-slate-700">
              <strong className="text-lg text-white">{cat.name}</strong>
              <ul className="pl-4 mt-2 space-y-2">
                {cat.subcategories.map(sub => (
                  <li key={sub.id} className="text-md text-slate-300">
                    - {sub.name}
                    <ul className="pl-6 text-sm text-slate-400">
                        {sub.attributes.map(attr => (
                            <li key={attr.id}>* {attr.name} ({attr.type}) {attr.required ? <span className="text-teal-400">[Obrigatório]</span> : ''}</li>
                        ))}
                    </ul>
                  </li>
                ))}
              </ul>
            </li>
          ))}
        </ul>
      </Card>
    </div>
  );
};

export default AdminCategoryManagement;