
import React, { useState, useEffect } from 'react';
import { City, Neighborhood } from '../../types';
import { api } from '../../services/mockApi';
import Card from '../../components/Card';
import Input from '../../components/Input';
import Button from '../../components/Button';
import Select from '../../components/Select';

const AdminLocationManagement: React.FC = () => {
  const [cities, setCities] = useState<City[]>([]);
  const [neighborhoods, setNeighborhoods] = useState<Neighborhood[]>([]);
  const [newCityName, setNewCityName] = useState('');
  const [selectedCityId, setSelectedCityId] = useState<string>('');
  const [newNeighborhoodName, setNewNeighborhoodName] = useState('');

  const fetchData = async () => {
    const citiesData = await api.getCities();
    setCities(citiesData);
    if (citiesData.length > 0) {
      const cityToSelect = selectedCityId || citiesData[0].id;
      setSelectedCityId(cityToSelect);
      const neighborhoodsData = await api.getNeighborhoodsByCity(cityToSelect);
      setNeighborhoods(neighborhoodsData);
    }
  };

  useEffect(() => {
    fetchData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (selectedCityId) {
      api.getNeighborhoodsByCity(selectedCityId).then(setNeighborhoods);
    }
  }, [selectedCityId]);

  const handleAddCity = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newCityName) {
      await api.addCity(newCityName);
      setNewCityName('');
      fetchData();
    }
  };

  const handleAddNeighborhood = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newNeighborhoodName && selectedCityId) {
      await api.addNeighborhood(selectedCityId, newNeighborhoodName);
      setNewNeighborhoodName('');
      const updatedNeighborhoods = await api.getNeighborhoodsByCity(selectedCityId);
      setNeighborhoods(updatedNeighborhoods);
    }
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <div className="space-y-6">
        <Card title="Adicionar Nova Cidade">
          <form onSubmit={handleAddCity} className="space-y-4">
            <Input
              label="Nome da Cidade"
              name="newCity"
              value={newCityName}
              onChange={(e) => setNewCityName(e.target.value)}
              required
            />
            <Button type="submit">Adicionar Cidade</Button>
          </form>
        </Card>
        <Card title="Adicionar Bairro">
          <form onSubmit={handleAddNeighborhood} className="space-y-4">
            <Select
              label="Selecione a Cidade"
              name="city"
              value={selectedCityId}
              onChange={(e) => setSelectedCityId(e.target.value)}
              required
            >
              {cities.map((city) => (
                <option key={city.id} value={city.id}>{city.name}</option>
              ))}
            </Select>
            <Input
              label="Nome do Bairro"
              name="newNeighborhood"
              value={newNeighborhoodName}
              onChange={(e) => setNewNeighborhoodName(e.target.value)}
              required
            />
            <Button type="submit">Adicionar Bairro</Button>
          </form>
        </Card>
      </div>
      <Card title="Localidades Cadastradas">
        <h3 className="text-lg font-semibold mb-2">Cidades</h3>
        <ul className="list-disc list-inside mb-4">
          {cities.map((city) => (
            <li key={city.id}>{city.name}</li>
          ))}
        </ul>
        <h3 className="text-lg font-semibold mb-2">Bairros de {cities.find(c => c.id === selectedCityId)?.name || '...'}</h3>
        <ul className="list-disc list-inside">
          {neighborhoods.map((n) => (
            <li key={n.id}>{n.name}</li>
          ))}
        </ul>
      </Card>
    </div>
  );
};

export default AdminLocationManagement;

