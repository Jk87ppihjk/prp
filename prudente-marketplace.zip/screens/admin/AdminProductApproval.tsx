import React, { useState, useEffect } from 'react';
import { Product } from '../../types';
import { api } from '../../services/mockApi';
import { ProductStatus } from '../../constants';
import Card from '../../components/Card';
import Button from '../../components/Button';
import Modal from '../../components/Modal';

const AdminProductApproval: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [rejectionReason, setRejectionReason] = useState('');

  const fetchProducts = async () => {
    setLoading(true);
    const pendingProducts = await api.getProductsByStatus(ProductStatus.PENDING);
    setProducts(pendingProducts);
    setLoading(false);
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  const handleApprove = async (productId: string) => {
    await api.approveProduct(productId);
    await fetchProducts();
    setSelectedProduct(null);
  };

  const handleReject = async () => {
    if (selectedProduct && rejectionReason) {
      await api.rejectProduct(selectedProduct.id, rejectionReason);
      await fetchProducts();
      setSelectedProduct(null);
      setRejectionReason('');
    }
  };

  if (loading) return <div>Carregando...</div>;

  return (
    <Card title="Aprovação de Produtos Pendentes">
      {products.length === 0 ? (
        <p>Nenhum produto pendente de aprovação.</p>
      ) : (
        <div className="space-y-4">
          {products.map((product) => (
            <div key={product.id} className="p-4 border border-slate-700 bg-slate-900/50 rounded-lg flex justify-between items-center">
              <div>
                <h3 className="font-semibold text-white">{product.name}</h3>
                <p className="text-sm text-slate-400">Preço: R$ {product.price.toFixed(2)}</p>
              </div>
              <Button onClick={() => setSelectedProduct(product)} className="w-auto">
                Ver Detalhes
              </Button>
            </div>
          ))}
        </div>
      )}

      {selectedProduct && (
        <Modal isOpen={!!selectedProduct} onClose={() => setSelectedProduct(null)} title="Detalhes do Produto">
          <div className="space-y-4 text-slate-300">
            <h3 className="text-lg font-bold text-white">{selectedProduct.name}</h3>
            <img src={selectedProduct.images[0] || 'https://picsum.photos/400/200'} alt={selectedProduct.name} className="w-full h-48 object-cover rounded-md"/>
            <p><strong>Descrição:</strong> {selectedProduct.description}</p>
            <p><strong>Preço:</strong> R$ {selectedProduct.price.toFixed(2)}</p>
            <p><strong>Estoque:</strong> {selectedProduct.stock}</p>
            <div>
                <strong className="text-white">Atributos:</strong>
                <ul className="list-disc list-inside text-slate-400">
                    {Object.entries(selectedProduct.attributes).map(([key, value]) => (
                        <li key={key}>{key}: {String(value)}</li>
                    ))}
                </ul>
            </div>
            <hr className="border-slate-600"/>
            <textarea
              className="w-full p-2 border rounded bg-slate-700 border-slate-600 text-white placeholder-slate-400"
              placeholder="Motivo da rejeição (obrigatório se for rejeitar)"
              value={rejectionReason}
              onChange={(e) => setRejectionReason(e.target.value)}
            />
            <div className="flex justify-end space-x-4">
              <Button variant="danger" onClick={handleReject} disabled={!rejectionReason}>
                Rejeitar
              </Button>
              <Button variant="primary" onClick={() => handleApprove(selectedProduct.id)}>
                Aprovar
              </Button>
            </div>
          </div>
        </Modal>
      )}
    </Card>
  );
};

export default AdminProductApproval;