import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useCart } from '../hooks/useCart';
import { useAuth } from '../hooks/useAuth';
import { api } from '../services/mockApi';
import { Buyer } from '../types';
import Card from '../components/Card';
import Button from '../components/Button';

const CheckoutScreen: React.FC = () => {
  const { cartItems, total, clearCart } = useCart();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [buyer, setBuyer] = useState<Buyer | null>(null);
  const [loading, setLoading] = useState(true);
  const [isPlacingOrder, setIsPlacingOrder] = useState(false);

  useEffect(() => {
    if (cartItems.length === 0) {
      navigate('/dashboard');
    }
    if (user) {
      api.getBuyerDetails(user.id).then(data => {
        setBuyer(data);
        setLoading(false);
      });
    }
  }, [user, cartItems, navigate]);

  const handleConfirmOrder = async () => {
    if (!user || !buyer?.shippingAddress) return;
    setIsPlacingOrder(true);
    try {
      await api.placeOrder(user.id, cartItems, buyer.shippingAddress);
      clearCart();
      navigate('/order-success');
    } catch (error: any) {
      alert(`Erro ao finalizar pedido: ${error.message}`);
    } finally {
      setIsPlacingOrder(false);
    }
  };

  if (loading) {
    return <div className="text-center">Carregando...</div>;
  }

  return (
    <div className="max-w-3xl mx-auto fade-in">
      <h1 className="text-3xl font-bold text-white mb-6">Finalizar Compra</h1>
      <Card>
        {!buyer?.shippingAddress?.street ? (
          <div className="text-center">
            <h2 className="text-xl font-bold text-yellow-300 mb-2">Endereço de Entrega Faltando</h2>
            <p className="text-slate-400 mb-4">Você precisa cadastrar um endereço de entrega para poder finalizar a compra.</p>
            <Link to="/profile">
              <Button>Cadastrar Endereço</Button>
            </Link>
          </div>
        ) : (
          <div className="space-y-6">
            <div>
              <h2 className="text-xl font-bold text-white mb-2">Endereço de Entrega</h2>
              <div className="text-slate-300 p-4 bg-slate-700 rounded-md">
                <p>{buyer.shippingAddress.street}, {buyer.shippingAddress.number}</p>
                <p>{buyer.shippingAddress.complement}</p>
                <p>CEP: {buyer.shippingAddress.zipCode}</p>
              </div>
            </div>
            <div>
              <h2 className="text-xl font-bold text-white mb-2">Resumo do Pedido</h2>
              <div className="space-y-2">
                {cartItems.map(item => (
                  <div key={item.id} className="flex justify-between text-sm">
                    <span>{item.name} (x{item.quantity})</span>
                    <span>R$ {(item.price * item.quantity).toFixed(2)}</span>
                  </div>
                ))}
                <div className="border-t border-slate-700 my-2 pt-2 flex justify-between font-bold text-lg">
                  <span className="text-white">Total</span>
                  <span className="text-sky-400">R$ {total.toFixed(2)}</span>
                </div>
              </div>
            </div>
            <Button 
                onClick={handleConfirmOrder} 
                isLoading={isPlacingOrder}
                disabled={isPlacingOrder}
            >
              Confirmar Compra
            </Button>
          </div>
        )}
      </Card>
    </div>
  );
};

export default CheckoutScreen;
