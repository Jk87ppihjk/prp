import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import Card from '../components/Card';
import Input from '../components/Input';
import Button from '../components/Button';

const LoginScreen: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);
    try {
      await login(email, password);
      navigate('/');
    } catch (err: any) {
      setError(err.message || 'Falha no login. Verifique suas credenciais.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-full flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8">
        <div>
          <h2 className="mt-6 text-center text-3xl font-extrabold text-white">
            Acesse sua conta
          </h2>
          <p className="mt-2 text-center text-sm text-slate-400">
            Ou{' '}
            <Link to="/register" className="font-medium text-sky-400 hover:text-sky-300">
              crie uma nova conta
            </Link>
          </p>
        </div>

        <div className="bg-slate-800 border border-teal-500/30 text-slate-300 p-4 rounded-lg text-sm shadow-lg">
            <h4 className="font-bold mb-2 text-white">Usuários de Teste:</h4>
            <p className="text-xs text-slate-400">Clique para preencher e entrar rapidamente.</p>
            <div className="mt-3 space-y-2">
                <button 
                onClick={() => { setEmail('comprador@email.com'); setPassword('password123'); }}
                className="w-full text-left p-2 bg-slate-700 rounded-md hover:bg-slate-600 text-xs shadow-sm border border-slate-600 transition-all duration-200 transform hover:scale-[1.02]"
                >
                <strong className="text-sky-400">Comprador:</strong> comprador@email.com
                </button>
                <button 
                onClick={() => { setEmail('vendedor@email.com'); setPassword('password123'); }}
                className="w-full text-left p-2 bg-slate-700 rounded-md hover:bg-slate-600 text-xs shadow-sm border border-slate-600 transition-all duration-200 transform hover:scale-[1.02]"
                >
                <strong className="text-teal-400">Vendedor:</strong> vendedor@email.com
                </button>
            </div>
        </div>

        <Card>
          <form className="space-y-6" onSubmit={handleSubmit}>
            {error && <p className="text-red-400 text-sm text-center">{error}</p>}
            <Input
              label="Email"
              name="email"
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
            <div>
                <Input
                label="Senha"
                name="password"
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                />
                <div className="text-right mt-2">
                    <Link to="/forgot-password" className="text-sm font-medium text-sky-400 hover:text-sky-300">
                        Esqueceu a senha?
                    </Link>
                </div>
            </div>
            <Button type="submit" isLoading={isLoading}>
              Entrar
            </Button>
          </form>
        </Card>
      </div>
    </div>
  );
};

export default LoginScreen;