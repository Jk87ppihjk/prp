import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { Store, Product } from '../types';
import { api } from '../services/mockApi';
import Card from '../components/Card';
import NotFound from './NotFound';
import { ShoppingCartIcon } from '../components/icons/ShoppingCartIcon';
import { useCart } from '../hooks/useCart';

const StorePage: React.FC = () => {
  const { storeId } = useParams<{ storeId: string }>();
  const { addToCart } = useCart();
  const [store, setStore] = useState<Store | null>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [addedProducts, setAddedProducts] = useState<string[]>([]);

  useEffect(() => {
    if (storeId) {
      const fetchStoreData = async () => {
        setLoading(true);
        try {
          const [storeData, productsData] = await Promise.all([
            api.getStoreById(storeId),
            api.getApprovedProductsByStoreId(storeId),
          ]);
          setStore(storeData);
          setProducts(productsData);
        } catch (error) {
          console.error("Failed to fetch store data:", error);
          setStore(null);
        } finally {
          setLoading(false);
        }
      };
      fetchStoreData();
    }
  }, [storeId]);

  const handleAddToCart = (product: Product) => {
    addToCart(product);
    setAddedProducts(prev => [...prev, product.id]);
    setTimeout(() => {
        setAddedProducts(prev => prev.filter(id => id !== product.id));
    }, 2000);
  };

  if (loading) {
    return <div className="flex justify-center items-center h-screen"><div className="animate-spin rounded-full h-32 w-32 border-t-2 border-b-2 border-sky-400"></div></div>;
  }

  if (!store) {
    return <NotFound />;
  }

  return (
    <div className="space-y-8 fade-in">
      <Card noPadding>
        <div className="relative">
          <img src={store.bannerUrl || 'https://picsum.photos/1200/300'} alt={`${store.name} banner`} className="w-full h-48 md:h-64 object-cover" />
           <div className="absolute inset-0 bg-gradient-to-t from-slate-800 to-transparent"></div>
          <div className="absolute bottom-0 left-6 transform translate-y-1/2">
            <img src={store.logoUrl || 'https://picsum.photos/200'} alt={`${store.name} logo`} className="h-24 w-24 md:h-32 md:w-32 rounded-full border-4 border-slate-800 bg-slate-700 object-contain shadow-lg" />
          </div>
        </div>
        <div className="pt-16 md:pt-20 px-6 pb-6">
          <h1 className="text-3xl font-bold text-white">{store.name}</h1>
          <p className="mt-2 text-slate-400">{store.bio}</p>
        </div>
      </Card>

      <div>
        <h2 className="text-2xl font-bold text-white mb-4">Produtos da Loja</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {products.length > 0 ? (
             products.map((product, index) => (
                <Card key={product.id} noPadding className="flex flex-col group overflow-hidden transform transition-all duration-300 hover:scale-105 hover:shadow-2xl hover:shadow-sky-500/20" style={{ animationDelay: `${index * 50}ms` }}>
                    <div className="relative">
                        <img src={product.images[0] || 'https://picsum.photos/400/300'} alt={product.name} className="w-full h-48 object-cover transition-transform duration-300 group-hover:scale-110"/>
                        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                        <span className="absolute top-2 right-2 bg-slate-900/50 text-white text-xs font-bold py-1 px-3 rounded-full backdrop-blur-sm">R$ {product.price.toFixed(2)}</span>
                    </div>
                    <div className="p-4 flex flex-col flex-grow">
                        <h3 className="font-bold text-lg text-white truncate">{product.name}</h3>
                        <p className="text-slate-400 text-sm mt-1 flex-grow line-clamp-2">{product.description}</p>
                        <div className="mt-4">
                            <button
                                onClick={() => handleAddToCart(product)}
                                disabled={addedProducts.includes(product.id)}
                                className={`w-full text-white text-sm font-bold py-2 px-3 rounded-md transition-all flex items-center justify-center gap-2 transform hover:scale-105 ${addedProducts.includes(product.id) ? 'bg-green-500 cursor-not-allowed' : 'bg-sky-500 hover:bg-sky-400'}`}
                            >
                                {addedProducts.includes(product.id) ? (
                                    'Adicionado ✓'
                                ) : (
                                    <>
                                        <ShoppingCartIcon />
                                        Comprar
                                    </>
                                )}
                            </button>
                        </div>
                    </div>
                </Card>
            ))
          ) : (
            <p className="col-span-full text-center text-slate-400">Esta loja ainda não tem produtos disponíveis.</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default StorePage;
