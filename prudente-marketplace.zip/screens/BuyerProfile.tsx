import React, { useState, useEffect } from 'react';
import { Buyer, Address, Order } from '../types';
import { useAuth } from '../hooks/useAuth';
import { api } from '../services/mockApi';
import Card from '../components/Card';
import AddressForm from '../components/AddressForm';

const OrderHistory: React.FC<{ buyerId: string }> = ({ buyerId }) => {
    const [orders, setOrders] = useState<Order[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchOrders = async () => {
            setLoading(true);
            const data = await api.getOrdersByBuyerId(buyerId);
            setOrders(data);
            setLoading(false);
        };
        fetchOrders();
    }, [buyerId]);

    if (loading) return <div>Carregando histórico de pedidos...</div>;

    return (
        <div className="space-y-6">
            <h2 className="text-2xl font-bold text-white">Meus Pedidos</h2>
            {orders.length === 0 ? (
                <p className="text-slate-400">Você ainda não fez nenhum pedido.</p>
            ) : (
                orders.map(order => (
                    <Card key={order.id}>
                        <div className="flex justify-between items-start">
                            <div>
                                <h3 className="font-bold text-lg text-white">Pedido #{order.id.slice(-6)}</h3>
                                <p className="text-sm text-slate-400">Data: {new Date(order.date).toLocaleDateString('pt-BR')}</p>
                            </div>
                            <div className="text-right">
                                <p className="font-bold text-sky-400 text-xl">R$ {order.totalPrice.toFixed(2)}</p>
                            </div>
                        </div>
                        <div className="mt-4 border-t border-slate-700 pt-4">
                            <h4 className="font-semibold text-slate-300 mb-2">Itens:</h4>
                            <ul className="space-y-2">
                                {order.items.map(item => (
                                    <li key={item.productId} className="flex justify-between text-sm">
                                        <span className="text-slate-300">{item.productName} (x{item.quantity})</span>
                                        <span className="text-slate-400">R$ {(item.price * item.quantity).toFixed(2)}</span>
                                    </li>
                                ))}
                            </ul>
                        </div>
                    </Card>
                ))
            )}
        </div>
    );
};

const BuyerProfile: React.FC = () => {
    const { user } = useAuth();
    const [buyer, setBuyer] = useState<Buyer | null>(null);
    const [loading, setLoading] = useState(true);
    const [activeTab, setActiveTab] = useState('address');

    useEffect(() => {
        const fetchBuyer = async () => {
            if (user) {
                setLoading(true);
                const data = await api.getBuyerDetails(user.id);
                setBuyer(data);
                setLoading(false);
            }
        };
        fetchBuyer();
    }, [user]);

    const handleSaveAddress = async (address: Address) => {
        if (buyer) {
            await api.saveBuyerAddress(buyer.id, address);
            setBuyer(prev => prev ? ({ ...prev, shippingAddress: address }) : null);
        }
    };

    if (loading) return <div className="text-center p-10">Carregando perfil...</div>;
    if (!buyer) return <div className="text-center p-10 text-red-400">Não foi possível carregar os dados do usuário.</div>;

    return (
        <div className="max-w-4xl mx-auto">
            <h1 className="text-3xl font-bold text-white mb-6">Meu Perfil</h1>
            
            <div className="mb-6 border-b border-slate-700">
                <nav className="-mb-px flex space-x-8" aria-label="Tabs">
                    <button
                        onClick={() => setActiveTab('address')}
                        className={`whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                            activeTab === 'address' ? 'border-sky-400 text-sky-400' : 'border-transparent text-slate-400 hover:text-slate-200 hover:border-slate-500'
                        }`}
                    >
                        Meus Dados
                    </button>
                    <button
                        onClick={() => setActiveTab('orders')}
                        className={`whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                            activeTab === 'orders' ? 'border-sky-400 text-sky-400' : 'border-transparent text-slate-400 hover:text-slate-200 hover:border-slate-500'
                        }`}
                    >
                        Meus Pedidos
                    </button>
                </nav>
            </div>

            <div>
                {activeTab === 'address' && (
                    <Card>
                        <AddressForm
                            title="Endereço de Entrega"
                            initialAddress={buyer.shippingAddress || { cityId: buyer.cityId }}
                            onSave={handleSaveAddress}
                        />
                    </Card>
                )}
                {activeTab === 'orders' && (
                    <OrderHistory buyerId={buyer.id} />
                )}
            </div>
        </div>
    );
};

export default BuyerProfile;
