import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Card from '../components/Card';
import { Product, Buyer, Store, City } from '../types';
import { api } from '../services/mockApi';
import { useAuth } from '../hooks/useAuth';
import Select from '../components/Select';
import { ShoppingCartIcon } from '../components/icons/ShoppingCartIcon';
import { useCart } from '../hooks/useCart';

const BuyerDashboard: React.FC = () => {
    const { user } = useAuth();
    const { addToCart } = useCart();
    const [buyer, setBuyer] = useState<Buyer | null>(null);
    const [cities, setCities] = useState<City[]>([]);
    const [selectedCityId, setSelectedCityId] = useState<string>('');
    const [stores, setStores] = useState<Store[]>([]);
    const [products, setProducts] = useState<Product[]>([]);
    const [loading, setLoading] = useState(true);
    const [addedProducts, setAddedProducts] = useState<string[]>([]);

    // Fetch initial buyer and city data
    useEffect(() => {
        const fetchInitialData = async () => {
            if (user) {
                const [buyerData, cityData] = await Promise.all([
                    api.getBuyerDetails(user.id),
                    api.getCities()
                ]);
                setBuyer(buyerData);
                setCities(cityData);
                if (buyerData.cityId) {
                    setSelectedCityId(buyerData.cityId);
                } else if (cityData.length > 0) {
                    setSelectedCityId(cityData[0].id);
                }
            }
        };
        fetchInitialData();
    }, [user]);

    // Fetch stores and products when selected city changes
    useEffect(() => {
        if (selectedCityId) {
            setLoading(true);
            const fetchDataForCity = async () => {
                const [storesData, productsData] = await Promise.all([
                    api.getStoresByCityId(selectedCityId),
                    api.getApprovedProductsByCityId(selectedCityId)
                ]);
                setStores(storesData);
                setProducts(productsData);
                setLoading(false);
            };
            fetchDataForCity();
        }
    }, [selectedCityId]);

    const handleAddToCart = (product: Product) => {
        addToCart(product);
        setAddedProducts(prev => [...prev, product.id]);
        setTimeout(() => {
            setAddedProducts(prev => prev.filter(id => id !== product.id));
        }, 2000);
    };

    const selectedCityName = cities.find(c => c.id === selectedCityId)?.name || 'sua cidade';

    return (
        <div className="space-y-10 fade-in">
            {!buyer?.shippingAddress?.street && (
                <div className="bg-yellow-900/50 border-l-4 border-yellow-400 text-yellow-200 p-4 rounded-md" role="alert">
                    <p className="font-bold">Endereço Pendente</p>
                    <p>Por favor, <Link to="/profile" className="font-semibold underline hover:text-yellow-100">adicione seu endereço de entrega</Link> para poder finalizar suas compras.</p>
                </div>
            )}

            <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
                 <h1 className="text-4xl font-extrabold text-white tracking-tight">Bem-vindo à <span className="text-sky-400">Prudente</span>!</h1>
                 <div className="w-full sm:w-64">
                    <Select label="Ver lojas e produtos em:" name="cityFilter" value={selectedCityId} onChange={e => setSelectedCityId(e.target.value)}>
                        {cities.map(city => <option key={city.id} value={city.id}>{city.name}</option>)}
                    </Select>
                 </div>
            </div>

            {/* Stores Section */}
            <div>
                <h2 className="text-2xl font-bold text-white mb-4">Lojas em <span className="text-teal-400">{selectedCityName}</span></h2>
                {loading ? <div className="text-center">Carregando lojas...</div> : (
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                        {stores.length > 0 ? (
                            stores.map((store, index) => (
                                <Link to={`/store/${store.id}`} key={store.id} style={{ animationDelay: `${index * 50}ms` }} className="fade-in">
                                    <Card noPadding className="group overflow-hidden transform transition-all duration-300 hover:scale-105 hover:shadow-2xl hover:shadow-teal-500/20">
                                        <div className="p-6 flex flex-col items-center text-center">
                                            <img src={store.logoUrl || 'https://picsum.photos/200'} alt={store.name} className="w-24 h-24 rounded-full object-contain p-1 border-2 border-slate-600 group-hover:border-teal-400 transition-colors"/>
                                            <h3 className="font-semibold text-white mt-4 text-lg">{store.name}</h3>
                                            <p className="text-slate-400 text-sm mt-1 line-clamp-2">{store.bio}</p>
                                        </div>
                                    </Card>
                                </Link>
                            ))
                        ) : (
                            <p className="col-span-full text-center text-slate-400">Nenhuma loja encontrada nesta cidade.</p>
                        )}
                    </div>
                )}
            </div>

            {/* Products Section */}
            <div>
                 <h2 className="text-2xl font-bold text-white mb-4">Produtos em <span className="text-sky-400">{selectedCityName}</span></h2>
                 {loading ? <div className="text-center">Carregando produtos...</div> : (
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                        {products.length > 0 ? (
                            products.map((product, index) => (
                                <Card key={product.id} noPadding className="flex flex-col group overflow-hidden transform transition-all duration-300 hover:scale-105 hover:shadow-2xl hover:shadow-sky-500/20" style={{ animationDelay: `${index * 50}ms` }}>
                                    <div className="relative">
                                        <img src={product.images[0] || 'https://picsum.photos/400/300'} alt={product.name} className="w-full h-48 object-cover transition-transform duration-300 group-hover:scale-110"/>
                                        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                                        <span className="absolute top-2 right-2 bg-slate-900/50 text-white text-xs font-bold py-1 px-3 rounded-full backdrop-blur-sm">R$ {product.price.toFixed(2)}</span>
                                    </div>
                                    <div className="p-4 flex flex-col flex-grow">
                                        <h3 className="font-bold text-lg text-white truncate">{product.name}</h3>
                                        <p className="text-slate-400 text-sm mt-1 flex-grow line-clamp-2">{product.description}</p>
                                        <div className="mt-4">
                                            <button 
                                                onClick={() => handleAddToCart(product)}
                                                disabled={addedProducts.includes(product.id)}
                                                className={`w-full text-white text-sm font-bold py-2 px-3 rounded-md transition-all flex items-center justify-center gap-2 transform hover:scale-105 ${addedProducts.includes(product.id) ? 'bg-green-500 cursor-not-allowed' : 'bg-sky-500 hover:bg-sky-400'}`}
                                            >
                                                {addedProducts.includes(product.id) ? (
                                                    'Adicionado ✓'
                                                ) : (
                                                    <>
                                                        <ShoppingCartIcon />
                                                        Comprar
                                                    </>
                                                )}
                                            </button>
                                        </div>
                                    </div>
                                </Card>
                            ))
                        ) : (
                            <p className="col-span-full text-center text-slate-400">Nenhum produto disponível nesta cidade.</p>
                        )}
                    </div>
                )}
            </div>
        </div>
    );
};

export default BuyerDashboard;
