import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import Card from '../components/Card';
import Input from '../components/Input';
import Button from '../components/Button';

const ForgotPasswordScreen: React.FC = () => {
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setMessage('');
    setIsLoading(true);

    try {
      const response = await fetch('https://aldei.onrender.com/api/forgot-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email })
      });
      
      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || 'Ocorreu um erro.');
      }
      
      setMessage(data.message);

      // Navigate to reset password screen after showing the message
      setTimeout(() => {
        navigate('/reset-password', { state: { email } });
      }, 2000);

    } catch (err: any) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-full flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8">
        <div>
          <h2 className="mt-6 text-center text-3xl font-extrabold text-white">
            Recuperar Senha
          </h2>
          <p className="mt-2 text-center text-sm text-slate-400">
            Digite seu e-mail para receber um código de redefinição.
          </p>
        </div>
        <Card>
          <form className="space-y-6" onSubmit={handleSubmit}>
            {error && <p className="text-red-400 text-sm text-center bg-red-900/20 p-3 rounded-md">{error}</p>}
            {message && <p className="text-green-400 text-sm text-center bg-green-900/20 p-3 rounded-md">{message}</p>}
            
            <Input
              label="Seu E-mail"
              name="email"
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              autoComplete="email"
            />
            
            <Button type="submit" isLoading={isLoading} disabled={isLoading || !!message}>
              Enviar Código
            </Button>
          </form>
        </Card>
        <div className="text-center text-sm">
            <Link to="/login" className="font-medium text-slate-400 hover:text-sky-300">
                Lembrou a senha? Voltar para o Login
            </Link>
        </div>
      </div>
    </div>
  );
};

export default ForgotPasswordScreen;