import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation, Link } from 'react-router-dom';
import Card from '../components/Card';
import Input from '../components/Input';
import Button from '../components/Button';

const VerifyEmailScreen: React.FC = () => {
  const [code, setCode] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  const email = location.state?.email;

  useEffect(() => {
    // If there's no email in the state, user probably landed here directly.
    // Redirect them to registration.
    if (!email) {
      navigate('/register');
    }
  }, [email, navigate]);
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    setIsLoading(true);

    try {
      const response = await fetch('https://aldei.onrender.com/api/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, code })
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || 'Falha na verificação.');
      }
      
      setSuccess(data.message);
      
      // Redirect to login after a short delay
      setTimeout(() => {
        navigate('/login');
      }, 2000);

    } catch (err: any) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-full flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8">
        <div>
          <h2 className="mt-6 text-center text-3xl font-extrabold text-white">
            Verifique seu E-mail
          </h2>
          <p className="mt-2 text-center text-sm text-slate-400">
            Enviamos um código de 4 dígitos para <strong className="text-sky-400">{email}</strong>.
          </p>
        </div>
        <Card>
          <form className="space-y-6" onSubmit={handleSubmit}>
            {error && <p className="text-red-400 text-sm text-center bg-red-900/20 p-3 rounded-md">{error}</p>}
            {success && <p className="text-green-400 text-sm text-center bg-green-900/20 p-3 rounded-md">{success}</p>}
            
            <Input
              label="Código de Verificação"
              name="code"
              type="text"
              required
              value={code}
              onChange={(e) => setCode(e.target.value)}
              maxLength={4}
              autoComplete="one-time-code"
            />
            
            <Button type="submit" isLoading={isLoading} disabled={isLoading || !!success}>
              {success ? 'Verificado!' : 'Verificar e Ativar Conta'}
            </Button>
          </form>
        </Card>
        <div className="text-center text-sm">
            <Link to="/login" className="font-medium text-slate-400 hover:text-sky-300">
                Voltar para o Login
            </Link>
        </div>
      </div>
    </div>
  );
};

export default VerifyEmailScreen;