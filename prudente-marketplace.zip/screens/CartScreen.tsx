import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useCart } from '../hooks/useCart';
import Card from '../components/Card';
import Button from '../components/Button';

const CartScreen: React.FC = () => {
  const { cartItems, updateQuantity, removeFromCart, total } = useCart();
  const navigate = useNavigate();

  return (
    <div className="max-w-4xl mx-auto fade-in">
      <h1 className="text-3xl font-bold text-white mb-6">Meu Carrinho</h1>
      {cartItems.length === 0 ? (
        <Card>
          <div className="text-center">
            <p className="text-slate-400 mb-4">Seu carrinho está vazio.</p>
            <Link to="/dashboard">
              <Button>Continuar Comprando</Button>
            </Link>
          </div>
        </Card>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-4">
            {cartItems.map(item => (
              <Card key={item.id} noPadding className="flex items-center p-4">
                <img src={item.images[0]} alt={item.name} className="w-20 h-20 object-cover rounded-md" />
                <div className="flex-grow ml-4">
                  <h3 className="font-semibold text-white">{item.name}</h3>
                  <p className="text-sm text-slate-400">R$ {item.price.toFixed(2)}</p>
                </div>
                <div className="flex items-center space-x-3">
                  <input
                    type="number"
                    min="1"
                    value={item.quantity}
                    onChange={(e) => updateQuantity(item.id, parseInt(e.target.value, 10) || 1)}
                    className="w-16 bg-slate-700 border-slate-600 rounded-md text-center"
                  />
                   <p className="font-semibold text-white w-24 text-right">R$ {(item.price * item.quantity).toFixed(2)}</p>
                  <button onClick={() => removeFromCart(item.id)} className="text-red-400 hover:text-red-300">&times;</button>
                </div>
              </Card>
            ))}
          </div>

          <div className="lg:col-span-1">
            <Card>
              <h2 className="text-xl font-bold text-white mb-4">Resumo do Pedido</h2>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-400">Subtotal</span>
                  <span className="text-white">R$ {total.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Frete</span>
                  <span className="text-white">Grátis</span>
                </div>
                <div className="border-t border-slate-700 my-2"></div>
                <div className="flex justify-between font-bold text-lg">
                  <span className="text-white">Total</span>
                  <span className="text-sky-400">R$ {total.toFixed(2)}</span>
                </div>
              </div>
              <Button onClick={() => navigate('/checkout')} className="mt-6">Finalizar Compra</Button>
            </Card>
          </div>
        </div>
      )}
    </div>
  );
};

export default CartScreen;
