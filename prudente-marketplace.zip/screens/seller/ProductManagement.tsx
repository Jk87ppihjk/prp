import React, { useState, useEffect } from 'react';
import { Product, Category, Subcategory, Attribute } from '../../types';
import { api } from '../../services/mockApi';
import { useAuth } from '../../hooks/useAuth';
import Card from '../../components/Card';
import Button from '../../components/Button';
import Modal from '../../components/Modal';
import Input from '../../components/Input';
import Select from '../../components/Select';

const ProductForm: React.FC<{
  product?: Product | null;
  onClose: () => void;
  onSave: () => void;
}> = ({ product, onClose, onSave }) => {
  const { user } = useAuth();
  const [formData, setFormData] = useState<Partial<Product>>(product || {
    name: '',
    description: '',
    price: 0,
    stock: 0,
    categoryId: '',
    subcategoryId: '',
    attributes: {},
    images: [],
  });
  const [categories, setCategories] = useState<Category[]>([]);
  const [subcategories, setSubcategories] = useState<Subcategory[]>([]);
  const [attributes, setAttributes] = useState<Attribute[]>([]);

  useEffect(() => {
    api.getCategories().then(setCategories);
  }, []);

  useEffect(() => {
    if (formData.categoryId) {
      const category = categories.find(c => c.id === formData.categoryId);
      setSubcategories(category?.subcategories || []);
      setFormData(f => ({ ...f, subcategoryId: '', attributes: {} }));
    }
  }, [formData.categoryId, categories]);

  useEffect(() => {
    if (formData.subcategoryId) {
      const subcategory = subcategories.find(s => s.id === formData.subcategoryId);
      setAttributes(subcategory?.attributes || []);
      const initialAttrs = subcategory?.attributes.reduce((acc, attr) => {
        acc[attr.name] = attr.type === 'CHECKBOX' ? false : '';
        return acc;
      }, {} as Record<string, any>) || {};
       setFormData(f => ({ ...f, attributes: { ...initialAttrs, ...f.attributes} }));
    }
  }, [formData.subcategoryId, subcategories]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target as HTMLInputElement;
    setFormData({ ...formData, [name]: type === 'number' ? parseFloat(value) || 0 : value });
  };
  
  const handleAttributeChange = (name: string, value: any) => {
    setFormData(f => ({
      ...f,
      attributes: { ...f.attributes, [name]: value },
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || user.role !== 'SELLER') return;

    const sellerStore = await api.getStoreBySellerId(user.id);
    if (!sellerStore) {
        alert("Você precisa criar uma loja primeiro!");
        return;
    }
    
    if (product) {
        // update
    } else {
        await api.addProduct({ ...formData as any, storeId: sellerStore.id });
    }
    onSave();
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <Input label="Nome do Produto" name="name" value={formData.name} onChange={handleChange} required />
      <Input label="Descrição" name="description" value={formData.description} onChange={handleChange} required />
      <div className="grid grid-cols-2 gap-4">
        <Input label="Preço" name="price" type="number" value={formData.price} onChange={handleChange} required />
        <Input label="Estoque" name="stock" type="number" value={formData.stock} onChange={handleChange} required />
      </div>
      <Select label="Categoria" name="categoryId" value={formData.categoryId} onChange={handleChange} required>
        <option value="">Selecione</option>
        {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
      </Select>
      {subcategories.length > 0 && (
        <Select label="Subcategoria" name="subcategoryId" value={formData.subcategoryId} onChange={handleChange} required>
          <option value="">Selecione</option>
          {subcategories.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
        </Select>
      )}
      {attributes.length > 0 && (
        <div className="p-4 border border-slate-700 bg-slate-900/50 rounded-md space-y-3">
          <h4 className="font-semibold text-white">Atributos Específicos</h4>
          {attributes.map(attr => (
            <div key={attr.id}>
              <label className="block text-sm font-medium text-slate-300">{attr.name} {attr.required && '*'}</label>
              {attr.type === 'TEXT' && <input type="text" className="mt-1 block w-full border bg-slate-700 border-slate-600 rounded-md shadow-sm py-2 px-3 text-white" value={formData.attributes?.[attr.name] || ''} onChange={e => handleAttributeChange(attr.name, e.target.value)} required={attr.required} />}
              {attr.type === 'CHECKBOX' && <input type="checkbox" className="mt-1 h-4 w-4 text-sky-500 bg-slate-700 border-slate-600 rounded" checked={!!formData.attributes?.[attr.name]} onChange={e => handleAttributeChange(attr.name, e.target.checked)} />}
              {attr.type === 'LIST' && (
                <select className="mt-1 block w-full border bg-slate-700 border-slate-600 rounded-md shadow-sm py-2 px-3 text-white" value={formData.attributes?.[attr.name] || ''} onChange={e => handleAttributeChange(attr.name, e.target.value)} required={attr.required}>
                  <option value="">Selecione</option>
                  {attr.options?.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                </select>
              )}
            </div>
          ))}
        </div>
      )}
      <div className="flex justify-end space-x-2 pt-4">
        <Button type="button" variant="secondary" onClick={onClose} className="bg-slate-600 hover:bg-slate-500">Cancelar</Button>
        <Button type="submit">Salvar</Button>
      </div>
    </form>
  );
};


const ProductManagement: React.FC = () => {
  const { user } = useAuth();
  const [products, setProducts] = useState<Product[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  const fetchProducts = async () => {
    if (user) {
      const data = await api.getProductsBySellerId(user.id);
      setProducts(data);
    }
  };

  useEffect(() => {
    fetchProducts();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  const handleSave = () => {
    setIsModalOpen(false);
    setSelectedProduct(null);
    fetchProducts();
  };
  
  const getStatusClass = (status: string) => {
    switch (status) {
      case 'PENDENTE': return 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30';
      case 'APROVADO': return 'bg-green-500/20 text-green-300 border-green-500/30';
      case 'REJEITADO': return 'bg-red-500/20 text-red-300 border-red-500/30';
      default: return 'bg-slate-500/20 text-slate-300 border-slate-500/30';
    }
  };

  return (
    <Card>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-white">Meus Produtos</h2>
        <Button onClick={() => { setSelectedProduct(null); setIsModalOpen(true); }}>Adicionar Produto</Button>
      </div>
      <div className="space-y-4">
        {products.length === 0 ? (
          <p className="text-slate-400">Você ainda não cadastrou nenhum produto.</p>
        ) : (
          products.map(product => (
            <div key={product.id} className="p-4 bg-slate-900/50 border border-slate-700 rounded-lg flex justify-between items-center">
              <div>
                <h3 className="font-semibold text-white">{product.name}</h3>
                <p className="text-sm text-sky-400">R$ {product.price.toFixed(2)}</p>
              </div>
              <div className="flex items-center space-x-4">
                 <span className={`px-3 py-1 inline-flex text-xs leading-5 font-semibold rounded-full border ${getStatusClass(product.status)}`}>
                    {product.status}
                </span>
                {product.status === 'REJEITADO' && <span className="text-sm text-red-400 cursor-pointer underline decoration-dotted" title={product.rejectionReason}>Detalhes</span>}
                <Button variant="secondary" className="w-auto !py-1.5 bg-slate-700 hover:bg-slate-600" onClick={() => { setSelectedProduct(product); setIsModalOpen(true);}}>Editar</Button>
              </div>
            </div>
          ))
        )}
      </div>
      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title={selectedProduct ? 'Editar Produto' : 'Novo Produto'}>
        <ProductForm product={selectedProduct} onClose={() => setIsModalOpen(false)} onSave={handleSave} />
      </Modal>
    </Card>
  );
};

export default ProductManagement;