import React, { useState, useEffect } from 'react';
import { Store, Category, City, Neighborhood, Address } from '../../types';
import { useAuth } from '../../hooks/useAuth';
import { api } from '../../services/mockApi';
import Card from '../../components/Card';
import Input from '../../components/Input';
import Button from '../../components/Button';
import Select from '../../components/Select';

const StoreSetup: React.FC = () => {
    const { user } = useAuth();
    const [store, setStore] = useState<Partial<Store> | null>(null);
    const [loading, setLoading] = useState(true);
    const [categories, setCategories] = useState<Category[]>([]);
    const [cities, setCities] = useState<City[]>([]);
    const [neighborhoods, setNeighborhoods] = useState<Neighborhood[]>([]);
    
    useEffect(() => {
        const loadData = async () => {
            if (!user) return;
            setLoading(true);
            const [sellerStore, cats, allCities] = await Promise.all([
                api.getStoreBySellerId(user.id),
                api.getCategories(),
                api.getCities()
            ]);
            
            // FIX: The default address object for a new store was missing required fields.
            // This now provides a complete, empty address structure to satisfy the `Address` type.
            setStore(sellerStore || { name: '', bio: '', categoryId: '', cityId: user.cityId, address: { street: '', number: '', neighborhoodId: '', cityId: user.cityId, state: '', zipCode: '' } });
            setCategories(cats);
            setCities(allCities);
            setLoading(false);
        };
        loadData();
    }, [user]);

    useEffect(() => {
      if (store?.address?.cityId) {
        api.getNeighborhoodsByCity(store.address.cityId).then(setNeighborhoods);
      }
    }, [store?.address?.cityId]);

    const handleAddressChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setStore(s => s ? ({ ...s, address: { ...s.address as Address, [name]: value } }) : null);
    };

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setStore(s => s ? ({ ...s, [name]: value }) : null);
    };

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, field: 'logoUrl' | 'bannerUrl') => {
        if (e.target.files && e.target.files[0]) {
            const file = e.target.files[0];
            const reader = new FileReader();
            reader.onloadend = () => {
                setStore(s => s ? ({ ...s, [field]: reader.result as string }) : null);
            };
            reader.readAsDataURL(file);
        }
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (store) {
            await api.saveStore(store as Store);
            alert("Loja salva com sucesso!");
        }
    };

    if (loading || !store) return <div>Carregando...</div>

    return (
        <Card title="Configurações da Loja">
            <form onSubmit={handleSubmit} className="space-y-6">
                <Input label="Nome da Loja" name="name" value={store.name} onChange={handleChange} required />
                <Select label="Tipo de Loja" name="categoryId" value={store.categoryId} onChange={handleChange} required>
                    <option value="">Selecione uma categoria</option>
                    {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                </Select>
                <div>
                    <label className="block text-sm font-medium text-slate-300">Bio da Loja</label>
                    <textarea name="bio" value={store.bio} onChange={handleChange} rows={3} className="mt-1 appearance-none block w-full px-3 py-2 border bg-slate-700 border-slate-600 rounded-md shadow-sm placeholder-slate-400 text-white focus:outline-none focus:ring-sky-500 focus:border-sky-500 sm:text-sm" required />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label className="block text-sm font-medium text-slate-300">Logo (PNG, JPG)</label>
                        <input type="file" accept="image/png, image/jpeg" onChange={e => handleFileChange(e, 'logoUrl')} className="mt-1 block w-full text-sm text-slate-400 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-sky-500/10 file:text-sky-300 hover:file:bg-sky-500/20"/>
                        {store.logoUrl && <img src={store.logoUrl} alt="Logo Preview" className="mt-2 h-24 w-24 object-cover rounded-full" />}
                    </div>
                     <div>
                        <label className="block text-sm font-medium text-slate-300">Banner (PNG, JPG)</label>
                        <input type="file" accept="image/png, image/jpeg" onChange={e => handleFileChange(e, 'bannerUrl')} className="mt-1 block w-full text-sm text-slate-400 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-sky-500/10 file:text-sky-300 hover:file:bg-sky-500/20"/>
                        {store.bannerUrl && <img src={store.bannerUrl} alt="Banner Preview" className="mt-2 h-24 w-full object-cover rounded-md" />}
                    </div>
                </div>

                <div className="pt-6 border-t border-slate-700">
                  <h3 className="text-lg font-medium text-white">Endereço da Loja</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                    <Input label="Rua" name="street" value={store.address?.street} onChange={handleAddressChange} required />
                    <Input label="Número" name="number" value={store.address?.number} onChange={handleAddressChange} required />
                    <Select label="Cidade" name="cityId" value={store.address?.cityId} onChange={handleAddressChange} required>
                      {cities.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                    </Select>
                    <Select label="Bairro" name="neighborhoodId" value={store.address?.neighborhoodId} onChange={handleAddressChange} required>
                      {neighborhoods.map(n => <option key={n.id} value={n.id}>{n.name}</option>)}
                    </Select>
                  </div>
                </div>

                <Button type="submit">Salvar Alterações</Button>
            </form>
        </Card>
    );
};

export default StoreSetup;