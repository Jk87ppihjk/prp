import React, { useState, useEffect } from 'react';
import { Seller, Address } from '../../types';
import { useAuth } from '../../hooks/useAuth';
import { api } from '../../services/mockApi';
import Card from '../../components/Card';
import AddressForm from '../../components/AddressForm';

const SellerProfile: React.FC = () => {
    const { user } = useAuth();
    const [seller, setSeller] = useState<Seller | null>(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchSeller = async () => {
            if (user) {
                setLoading(true);
                const data = await api.getSellerDetails(user.id);
                setSeller(data);
                setLoading(false);
            }
        };
        fetchSeller();
    }, [user]);

    const handleSaveAddress = async (address: Address) => {
        if (seller) {
            await api.saveSellerHomeAddress(seller.id, address);
            setSeller(prev => prev ? ({ ...prev, homeAddress: address }) : null);
        }
    };

    if (loading) return <div>Carregando perfil...</div>;
    if (!seller) return <div>Não foi possível carregar os dados do usuário.</div>;

    return (
        <Card>
            <AddressForm
                title="Endereço Residencial (para suas compras)"
                initialAddress={seller.homeAddress || { cityId: seller.cityId }}
                onSave={handleSaveAddress}
            />
        </Card>
    );
};

export default SellerProfile;
