import React, { useState, useEffect } from 'react';
import { Order } from '../../types';
import { api } from '../../services/mockApi';
import { useAuth } from '../../hooks/useAuth';
import Card from '../../components/Card';

const OrderManagement: React.FC = () => {
    const { user } = useAuth();
    const [orders, setOrders] = useState<Order[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchOrders = async () => {
            if (user) {
                setLoading(true);
                const store = await api.getStoreBySellerId(user.id);
                if (store) {
                    const data = await api.getOrdersByStoreId(store.id);
                    setOrders(data);
                }
                setLoading(false);
            }
        };
        fetchOrders();
    }, [user]);

    if (loading) return <div>Carregando pedidos...</div>;

    return (
        <Card>
            <h2 className="text-2xl font-bold text-white mb-6">Pedidos Recebidos</h2>
            {orders.length === 0 ? (
                <p className="text-slate-400">Você ainda não recebeu nenhum pedido.</p>
            ) : (
                <div className="space-y-6">
                    {orders.map(order => (
                        <div key={order.id} className="p-4 bg-slate-900/50 border border-slate-700 rounded-lg">
                            <div className="flex justify-between items-start">
                                <div>
                                    <h3 className="font-bold text-lg text-white">Pedido #{order.id.slice(-6)}</h3>
                                    <p className="text-sm text-slate-400">Data: {new Date(order.date).toLocaleDateString('pt-BR')}</p>
                                </div>
                                <div className="text-right">
                                    <p className="font-semibold text-sky-400 text-lg">
                                        R$ {order.items.reduce((acc, item) => acc + (item.price * item.quantity), 0).toFixed(2)}
                                    </p>
                                </div>
                            </div>
                            <div className="mt-4 border-t border-slate-600 pt-4">
                                <h4 className="font-semibold text-slate-300 mb-2">Itens vendidos:</h4>
                                <ul className="space-y-2">
                                    {order.items.map(item => (
                                        <li key={item.productId} className="flex justify-between text-sm">
                                            <span className="text-slate-300">{item.productName} (x{item.quantity})</span>
                                            <span className="text-slate-400">R$ {(item.price * item.quantity).toFixed(2)}</span>
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </Card>
    );
};

export default OrderManagement;
