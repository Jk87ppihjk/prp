import React, { useState, useEffect } from 'react';
import { useAuth } from '../../hooks/useAuth';
import { api } from '../../services/mockApi';
import { FyVideo, Product } from '../../types';
import Card from '../../components/Card';
import Button from '../../components/Button';
import Select from '../../components/Select';

// Helper to convert file to base64
const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = error => reject(error);
    });
};

const SellerFyManagement: React.FC = () => {
    const { user } = useAuth();
    const [videos, setVideos] = useState<FyVideo[]>([]);
    const [products, setProducts] = useState<Product[]>([]);
    const [loading, setLoading] = useState(true);
    const [isUploading, setIsUploading] = useState(false);

    // Form state
    const [selectedFile, setSelectedFile] = useState<File | null>(null);
    const [previewUrl, setPreviewUrl] = useState<string | null>(null);
    const [caption, setCaption] = useState('');
    const [selectedProductId, setSelectedProductId] = useState('');

    const fetchSellerData = async () => {
        if (user) {
            setLoading(true);
            const [sellerVideos, sellerProducts] = await Promise.all([
                api.getFyVideosBySellerId(user.id),
                api.getProductsBySellerId(user.id)
            ]);
            setVideos(sellerVideos);
            setProducts(sellerProducts.filter(p => p.status === 'APROVADO'));
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchSellerData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [user]);
    
    useEffect(() => {
        if (!selectedFile) {
            setPreviewUrl(null);
            return;
        }
        const objectUrl = URL.createObjectURL(selectedFile);
        setPreviewUrl(objectUrl);
        return () => URL.revokeObjectURL(objectUrl);
    }, [selectedFile]);

    const resetForm = () => {
        setSelectedFile(null);
        setPreviewUrl(null);
        setCaption('');
        setSelectedProductId('');
    };

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            setSelectedFile(e.target.files[0]);
        }
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!user || !selectedFile) return;

        setIsUploading(true);
        const store = await api.getStoreBySellerId(user.id);
        if (!store) {
            alert('Você precisa configurar sua loja primeiro!');
            setIsUploading(false);
            return;
        }

        try {
            const videoUrl = await fileToBase64(selectedFile);
            await api.addFyVideo({
                sellerId: user.id,
                storeId: store.id,
                videoUrl,
                caption,
                productId: selectedProductId || undefined,
            });
            resetForm();
            await fetchSellerData();
        } catch (error) {
            console.error(error);
            alert('Falha ao enviar o vídeo.');
        } finally {
            setIsUploading(false);
        }
    };

    const handleDelete = async (videoId: string) => {
        if (window.confirm('Tem certeza que deseja excluir este vídeo?')) {
            await api.deleteFyVideo(videoId);
            await fetchSellerData();
        }
    };

    return (
        <div className="space-y-8">
            <Card title="Publicar Vídeo no Feed (FY)">
                <form onSubmit={handleSubmit} className="space-y-6">
                    <div>
                        <label htmlFor="video-upload" className="block text-sm font-medium text-slate-300 mb-2">Arquivo de Vídeo (MP4)</label>
                        <input
                            id="video-upload"
                            type="file"
                            accept="video/mp4"
                            onChange={handleFileChange}
                            className="block w-full text-sm text-slate-400 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-sky-500/10 file:text-sky-300 hover:file:bg-sky-500/20"
                            required
                        />
                    </div>

                    {previewUrl && (
                        <div className="space-y-4">
                             <video src={previewUrl} controls className="w-full max-w-sm mx-auto rounded-lg bg-black"></video>
                            <textarea
                                value={caption}
                                onChange={e => setCaption(e.target.value)}
                                placeholder="Escreva uma legenda..."
                                className="w-full p-2 border rounded bg-slate-700 border-slate-600 text-white placeholder-slate-400"
                                rows={3}
                                required
                            />
                            <Select 
                                label="Vincular a um produto (Opcional)"
                                name="productLink"
                                value={selectedProductId}
                                onChange={e => setSelectedProductId(e.target.value)}
                            >
                                <option value="">Nenhum produto</option>
                                {products.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                            </Select>
                            <Button type="submit" isLoading={isUploading} disabled={isUploading}>
                                {isUploading ? 'Enviando...' : 'Publicar Vídeo'}
                            </Button>
                        </div>
                    )}
                </form>
            </Card>

            <Card title="Meus Vídeos Publicados">
                {loading ? <p>Carregando...</p> : videos.length === 0 ? (
                    <p className="text-slate-400">Você ainda não publicou nenhum vídeo.</p>
                ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
                        {videos.map(video => (
                            <div key={video.id} className="group relative">
                                <video src={video.videoUrl} className="w-full h-auto rounded-lg bg-black" />
                                <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity p-2 flex flex-col justify-end">
                                    <p className="text-white text-xs line-clamp-2">{video.caption}</p>
                                </div>
                                <button
                                    onClick={() => handleDelete(video.id)}
                                    className="absolute top-2 right-2 p-1.5 bg-red-600/80 hover:bg-red-500 text-white rounded-full transition-all opacity-0 group-hover:opacity-100"
                                    aria-label="Excluir vídeo"
                                >
                                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                                </button>
                            </div>
                        ))}
                    </div>
                )}
            </Card>
        </div>
    );
};

export default SellerFyManagement;