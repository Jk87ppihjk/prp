import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../services/mockApi';
import { FyVideoWithDetails } from '../types';
import Button from '../components/Button';

const ForYouScreen: React.FC = () => {
  const [videos, setVideos] = useState<FyVideoWithDetails[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchVideos = async () => {
      setLoading(true);
      try {
        const data = await api.getAllFyVideosWithDetails();
        setVideos(data);
      } catch (error) {
        console.error("Failed to fetch FY videos:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchVideos();
  }, []);

  if (loading) {
    return (
        <div className="flex justify-center items-center h-[calc(100vh-200px)]">
            <div className="animate-spin rounded-full h-24 w-24 border-t-2 border-b-2 border-sky-400"></div>
        </div>
    );
  }

  return (
    <div className="max-w-md mx-auto space-y-8 fade-in">
        <h1 className="text-3xl font-extrabold text-white tracking-tight text-center">Para Você</h1>
      {videos.length === 0 ? (
        <div className="text-center bg-slate-800 p-8 rounded-lg">
            <p className="text-slate-400">Nenhum vídeo foi publicado ainda. Volte em breve!</p>
        </div>
      ) : (
        videos.map(video => (
            <div key={video.id} className="bg-slate-800 rounded-lg shadow-xl overflow-hidden border border-slate-700 snap-start">
                <div className="p-4">
                    <Link to={`/store/${video.store.id}`} className="flex items-center gap-3">
                        <img src={video.store.logoUrl} alt={video.store.name} className="w-10 h-10 rounded-full object-contain bg-slate-700"/>
                        <span className="font-bold text-white hover:underline">{video.store.name}</span>
                    </Link>
                </div>

                <video 
                    src={video.videoUrl}
                    controls
                    muted
                    autoPlay
                    loop
                    playsInline
                    className="w-full aspect-video md:aspect-[9/16] object-cover bg-black"
                />

                <div className="p-4 space-y-3">
                    <p className="text-slate-300 text-sm"><span className="font-semibold text-white">{video.store.name}</span> {video.caption}</p>
                    
                    {video.product && (
                        <Link to={`/store/${video.store.id}`}>
                            <Button className="w-full !py-2 !text-sm">
                                Ver Produto: {video.product.name}
                            </Button>
                        </Link>
                    )}
                </div>
            </div>
        ))
      )}
    </div>
  );
};

export default ForYouScreen;