import React from 'react';
import { Link } from 'react-router-dom';

const NotFound: React.FC = () => {
  return (
    <div className="text-center py-20">
      <h1 className="text-6xl font-bold text-sky-400">404</h1>
      <p className="text-2xl mt-4 text-slate-300">Página não encontrada</p>
      <p className="mt-2 text-slate-400">
        A página que você está procurando não existe ou foi movida.
      </p>
      <Link to="/" className="mt-6 inline-block bg-sky-500 text-white font-bold py-2 px-4 rounded hover:bg-sky-400 transition-colors">
        Voltar para o Início
      </Link>
    </div>
  );
};

export default NotFound;