import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation, Link } from 'react-router-dom';
import Card from '../components/Card';
import Input from '../components/Input';
import Button from '../components/Button';

const ResetPasswordScreen: React.FC = () => {
  const [code, setCode] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  const email = location.state?.email;

  useEffect(() => {
    // If there's no email in the state, user probably landed here directly.
    // Redirect them to forgot password page.
    if (!email) {
      navigate('/forgot-password');
    }
  }, [email, navigate]);
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    setIsLoading(true);

    if (newPassword.length < 6) {
        setError("A nova senha deve ter pelo menos 6 caracteres.");
        setIsLoading(false);
        return;
    }

    try {
      const response = await fetch('https://aldei.onrender.com/api/reset-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, code, newPassword })
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || 'Falha ao redefinir a senha.');
      }
      
      setSuccess(data.message);
      
      // Redirect to login after a short delay
      setTimeout(() => {
        navigate('/login');
      }, 2000);

    } catch (err: any) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-full flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8">
        <div>
          <h2 className="mt-6 text-center text-3xl font-extrabold text-white">
            Redefinir sua Senha
          </h2>
          <p className="mt-2 text-center text-sm text-slate-400">
            Digite o código recebido em <strong className="text-sky-400">{email}</strong> e sua nova senha.
          </p>
        </div>
        <Card>
          <form className="space-y-6" onSubmit={handleSubmit}>
            {error && <p className="text-red-400 text-sm text-center bg-red-900/20 p-3 rounded-md">{error}</p>}
            {success && <p className="text-green-400 text-sm text-center bg-green-900/20 p-3 rounded-md">{success}</p>}
            
            <Input
              label="Código de 6 dígitos"
              name="code"
              type="text"
              required
              value={code}
              onChange={(e) => setCode(e.target.value)}
              maxLength={6}
              autoComplete="one-time-code"
            />
            
            <Input
              label="Nova Senha"
              name="newPassword"
              type="password"
              required
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
            />
            
            <Button type="submit" isLoading={isLoading} disabled={isLoading || !!success}>
              {success ? 'Senha Redefinida!' : 'Salvar Nova Senha'}
            </Button>
          </form>
        </Card>
         <div className="text-center text-sm">
            <Link to="/login" className="font-medium text-slate-400 hover:text-sky-300">
                Voltar para o Login
            </Link>
        </div>
      </div>
    </div>
  );
};

export default ResetPasswordScreen;