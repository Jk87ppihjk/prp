import React from 'react';
import { Link } from 'react-router-dom';
import Card from '../components/Card';
import Button from '../components/Button';

const OrderSuccessScreen: React.FC = () => {
  return (
    <div className="max-w-md mx-auto text-center py-12 fade-in">
      <Card>
        <div className="p-6">
          <svg className="mx-auto h-12 w-12 text-green-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          <h2 className="mt-4 text-2xl font-bold text-white">Pedido Realizado com Sucesso!</h2>
          <p className="mt-2 text-slate-400">Obrigado pela sua compra. Você pode acompanhar o status do seu pedido na seção "Meus Pedidos" em seu perfil.</p>
          <div className="mt-6">
            <Link to="/dashboard">
              <Button>Voltar para o Início</Button>
            </Link>
          </div>
        </div>
      </Card>
    </div>
  );
};

export default OrderSuccessScreen;
