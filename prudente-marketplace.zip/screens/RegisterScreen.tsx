import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import Card from '../components/Card';
import Input from '../components/Input';
import Button from '../components/Button';
import Select from '../components/Select';
import { Role } from '../constants';
import { api } from '../services/mockApi';
import { City } from '../types';

const RegisterScreen: React.FC = () => {
  const [role, setRole] = useState<Role>(Role.BUYER);
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [cityId, setCityId] = useState('');
  const [cities, setCities] = useState<City[]>([]);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchCities = async () => {
      const availableCities = await api.getCities();
      setCities(availableCities);
      if (availableCities.length > 0) {
        setCityId(availableCities[0].id);
      }
    };
    fetchCities();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    if (password.length < 6) {
      setError('A senha deve ter pelo menos 6 caracteres.');
      setIsLoading(false);
      return;
    }

    try {
      // NOTE: This now calls the REAL backend, not the mock API.
      // You would typically have a separate api.ts for backend calls.
      const response = await fetch('https://aldei.onrender.com/api/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fullName, email, password, cityId, role })
      });
      
      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || 'Erro ao realizar o cadastro.');
      }
      
      // On success, navigate to the verification screen
      navigate('/verify-email', { state: { email } });

    } catch (err: any) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-full flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8">
        <div>
          <h2 className="mt-6 text-center text-3xl font-extrabold text-white">
            Crie sua conta
          </h2>
           <p className="mt-2 text-center text-sm text-slate-400">
            Já tem uma conta?{' '}
            <Link to="/login" className="font-medium text-sky-400 hover:text-sky-300">
              Faça o login
            </Link>
          </p>
        </div>
        <Card>
          <form className="space-y-6" onSubmit={handleSubmit}>
            {error && <p className="text-red-400 text-sm text-center bg-red-900/20 p-3 rounded-md">{error}</p>}
            
            <div className="rounded-md shadow-sm -space-y-px">
                <div className="grid grid-cols-2 gap-4">
                    <button type="button" onClick={() => setRole(Role.BUYER)} className={`p-3 rounded-md text-sm font-medium transition-colors ${role === Role.BUYER ? 'bg-sky-500 text-white' : 'bg-slate-700 text-slate-200 hover:bg-slate-600'}`}>
                        Sou Comprador
                    </button>
                    <button type="button" onClick={() => setRole(Role.SELLER)} className={`p-3 rounded-md text-sm font-medium transition-colors ${role === Role.SELLER ? 'bg-teal-600 text-white' : 'bg-slate-700 text-slate-200 hover:bg-slate-600'}`}>
                        Sou Lojista
                    </button>
                </div>
            </div>

            <Input
              label="Nome Completo"
              name="fullName"
              type="text"
              required
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
            />
            <Input
              label="Email"
              name="email"
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
            <Input
              label="Senha"
              name="password"
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
             <Select
              label="Cidade"
              name="city"
              value={cityId}
              onChange={(e) => setCityId(e.target.value)}
              required
            >
              {cities.map((city) => (
                <option key={city.id} value={city.id}>{city.name}</option>
              ))}
            </Select>

            <Button type="submit" isLoading={isLoading}>
              Cadastrar
            </Button>
          </form>
        </Card>
      </div>
    </div>
  );
};

export default RegisterScreen;