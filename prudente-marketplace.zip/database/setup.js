// database/setup.js
import { dbPool } from '../server.js';
import dotenv from 'dotenv';

// Carrega variáveis de ambiente
dotenv.config();

/**
 * Script para inicializar o banco de dados.
 * - Deleta tabelas existentes para garantir um ambiente limpo.
 * - Cria todas as tabelas necessárias para o marketplace.
 * - Insere dados iniciais (cidades, categorias, usuário admin).
 * 
 * Para executar: npm run db:setup
 */
async function setupDatabase() {
  let connection;
  try {
    connection = await dbPool.getConnection();
    console.log('Conexão com o banco de dados estabelecida para o setup.');

    // Ordem de deleção é a inversa da criação para respeitar as chaves estrangeiras
    const dropQueries = [
      `DROP TABLE IF EXISTS order_items;`,
      `DROP TABLE IF EXISTS orders;`,
      `DROP TABLE IF EXISTS fy_videos;`,
      `DROP TABLE IF EXISTS products;`,
      `DROP TABLE IF EXISTS attributes;`,
      `DROP TABLE IF EXISTS subcategories;`,
      `DROP TABLE IF EXISTS stores;`,
      `DROP TABLE IF EXISTS users;`,
      `DROP TABLE IF EXISTS categories;`,
      `DROP TABLE IF EXISTS neighborhoods;`,
      `DROP TABLE IF EXISTS cities;`,
    ];

    console.log('Limpando banco de dados existente...');
    for (const query of dropQueries) {
      await connection.query(query);
    }
    console.log('Tabelas antigas removidas com sucesso.');

    const createQueries = [
      `CREATE TABLE cities (
        id VARCHAR(255) PRIMARY KEY,
        name VARCHAR(255) NOT NULL
      );`,
      `CREATE TABLE neighborhoods (
        id VARCHAR(255) PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        cityId VARCHAR(255) NOT NULL,
        FOREIGN KEY (cityId) REFERENCES cities(id) ON DELETE CASCADE
      );`,
      `CREATE TABLE categories (
        id VARCHAR(255) PRIMARY KEY,
        name VARCHAR(255) NOT NULL
      );`,
      `CREATE TABLE subcategories (
        id VARCHAR(255) PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        categoryId VARCHAR(255) NOT NULL,
        FOREIGN KEY (categoryId) REFERENCES categories(id) ON DELETE CASCADE
      );`,
      `CREATE TABLE attributes (
        id VARCHAR(255) PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        type ENUM('TEXT', 'CHECKBOX', 'LIST') NOT NULL,
        options JSON,
        required BOOLEAN NOT NULL DEFAULT FALSE,
        subcategoryId VARCHAR(255) NOT NULL,
        FOREIGN KEY (subcategoryId) REFERENCES subcategories(id) ON DELETE CASCADE
      );`,
      `CREATE TABLE users (
        id VARCHAR(255) PRIMARY KEY,
        fullName VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        cityId VARCHAR(255) NOT NULL,
        role ENUM('BUYER', 'SELLER', 'ADMIN') NOT NULL,
        verificationCode VARCHAR(4),
        isVerified BOOLEAN NOT NULL DEFAULT FALSE,
        resetCode VARCHAR(6) NULL,
        resetCodeExpires DATETIME NULL,
        FOREIGN KEY (cityId) REFERENCES cities(id)
      );`,
      `CREATE TABLE stores (
        id VARCHAR(255) PRIMARY KEY,
        sellerId VARCHAR(255) NOT NULL UNIQUE,
        name VARCHAR(255) NOT NULL,
        bio TEXT,
        logoUrl TEXT,
        bannerUrl TEXT,
        categoryId VARCHAR(255) NOT NULL,
        cityId VARCHAR(255) NOT NULL,
        address_street VARCHAR(255),
        address_number VARCHAR(50),
        address_complement VARCHAR(255),
        address_neighborhoodId VARCHAR(255),
        address_zipCode VARCHAR(20),
        address_state VARCHAR(100),
        FOREIGN KEY (sellerId) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (categoryId) REFERENCES categories(id),
        FOREIGN KEY (cityId) REFERENCES cities(id),
        FOREIGN KEY (address_neighborhoodId) REFERENCES neighborhoods(id)
      );`,
      `CREATE TABLE products (
        id VARCHAR(255) PRIMARY KEY,
        storeId VARCHAR(255) NOT NULL,
        name VARCHAR(255) NOT NULL,
        description TEXT NOT NULL,
        price DECIMAL(10, 2) NOT NULL,
        stock INT NOT NULL,
        categoryId VARCHAR(255) NOT NULL,
        subcategoryId VARCHAR(255),
        attributes JSON,
        images JSON,
        status ENUM('PENDENTE', 'APROVADO', 'REJEITADO') NOT NULL,
        rejectionReason TEXT,
        FOREIGN KEY (storeId) REFERENCES stores(id) ON DELETE CASCADE,
        FOREIGN KEY (categoryId) REFERENCES categories(id),
        FOREIGN KEY (subcategoryId) REFERENCES subcategories(id)
      );`,
      `CREATE TABLE fy_videos (
        id VARCHAR(255) PRIMARY KEY,
        sellerId VARCHAR(255) NOT NULL,
        storeId VARCHAR(255) NOT NULL,
        videoUrl TEXT NOT NULL,
        caption TEXT,
        productId VARCHAR(255),
        uploadDate DATETIME NOT NULL,
        FOREIGN KEY (sellerId) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (storeId) REFERENCES stores(id) ON DELETE CASCADE,
        FOREIGN KEY (productId) REFERENCES products(id) ON DELETE SET NULL
      );`,
      `CREATE TABLE orders (
        id VARCHAR(255) PRIMARY KEY,
        buyerId VARCHAR(255) NOT NULL,
        totalPrice DECIMAL(10, 2) NOT NULL,
        date DATETIME NOT NULL,
        shipping_street VARCHAR(255),
        shipping_number VARCHAR(50),
        shipping_complement VARCHAR(255),
        shipping_neighborhoodId VARCHAR(255),
        shipping_cityId VARCHAR(255),
        shipping_state VARCHAR(100),
        shipping_zipCode VARCHAR(20),
        FOREIGN KEY (buyerId) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (shipping_cityId) REFERENCES cities(id),
        FOREIGN KEY (shipping_neighborhoodId) REFERENCES neighborhoods(id)
      );`,
      `CREATE TABLE order_items (
        id INT AUTO_INCREMENT PRIMARY KEY,
        orderId VARCHAR(255) NOT NULL,
        productId VARCHAR(255) NOT NULL,
        storeId VARCHAR(255) NOT NULL,
        productName VARCHAR(255) NOT NULL,
        quantity INT NOT NULL,
        price DECIMAL(10, 2) NOT NULL,
        FOREIGN KEY (orderId) REFERENCES orders(id) ON DELETE CASCADE,
        FOREIGN KEY (productId) REFERENCES products(id) ON DELETE CASCADE,
        FOREIGN KEY (storeId) REFERENCES stores(id) ON DELETE CASCADE
      );`
    ];

    console.log('Criando novas tabelas...');
    for (const query of createQueries) {
      await connection.query(query);
    }
    console.log('Tabelas criadas com sucesso.');
    
    // Inserção de dados iniciais
    console.log('Inserindo dados iniciais...');
    await connection.query(`INSERT INTO cities (id, name) VALUES ('c1', 'Presidente Prudente'), ('c2', 'Álvares Machado'), ('c3', 'Marília'), ('c4', 'Bauru');`);
    
    // ATENÇÃO: A senha do administrador é armazenada em texto plano aqui apenas para fins de demonstração.
    // Em um ambiente de produção real, você DEVE usar um algoritmo de hash seguro (como bcrypt)
    // para armazenar as senhas. O backend precisará ser ajustado para usar bcrypt.hash() ao criar usuários
    // e bcrypt.compare() ao fazer login.
    const adminEmail = 'tutano172@gmail.com';
    const adminPassword = '88178591'; // Esta senha deve ser substituída por um HASH
    
    await connection.query(
      `INSERT INTO users (id, fullName, email, password, cityId, role, isVerified) VALUES (?, ?, ?, ?, ?, ?, ?);`,
      ['admin-01', 'Admin Prudente', adminEmail, adminPassword, 'c1', 'ADMIN', true]
    );
    console.log(`Usuário administrador criado com sucesso: ${adminEmail}`);

    console.log('Setup do banco de dados concluído com sucesso!');

  } catch (error) {
    console.error('Falha ao executar o setup do banco de dados:', error);
  } finally {
    if (connection) {
      connection.release();
      console.log('Conexão liberada.');
    }
    // Encerra o pool de conexões para que o script possa terminar
    await dbPool.end();
    console.log('Pool de conexões encerrado.');
  }
}

setupDatabase();