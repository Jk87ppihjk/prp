import React, { createContext, useState, useEffect, ReactNode } from 'react';
import { User } from '../types';
import { Role } from '../constants';

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isAdmin: boolean;
  isSeller: boolean;
  isBuyer: boolean;
  login: (email: string, pass: string) => Promise<User | null>;
  logout: () => void;
  loading: boolean;
}

export const AuthContext = createContext<AuthContextType | undefined>(undefined);

const API_BASE_URL = 'https://aldei.onrender.com';

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const checkSession = () => {
      try {
        const token = localStorage.getItem('authToken');
        const storedUser = localStorage.getItem('authUser');
        if (token && storedUser) {
          // NOTE: For full security, we should verify the token's expiration
          // and ideally have a `/me` endpoint to re-fetch user data.
          // For this implementation, we trust the stored data.
          setUser(JSON.parse(storedUser));
        }
      } catch (error) {
        console.error("Failed to load user session from storage", error);
        localStorage.removeItem('authToken');
        localStorage.removeItem('authUser');
        setUser(null);
      } finally {
        setLoading(false);
      }
    };
    checkSession();
  }, []);

  const login = async (email: string, pass: string) => {
    setLoading(true);
    try {
      const response = await fetch(`${API_BASE_URL}/api/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password: pass })
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || 'Falha no login.');
      }

      const { token: authToken, user: loggedInUser } = data;

      localStorage.setItem('authToken', authToken);
      localStorage.setItem('authUser', JSON.stringify(loggedInUser));
      setUser(loggedInUser);

      return loggedInUser;
    } catch (error) {
      localStorage.removeItem('authToken');
      localStorage.removeItem('authUser');
      setUser(null);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const logout = () => {
    localStorage.removeItem('authToken');
    localStorage.removeItem('authUser');
    setUser(null);
  };

  const isAuthenticated = !!user;
  const isAdmin = user?.role === Role.ADMIN;
  const isSeller = user?.role === Role.SELLER;
  const isBuyer = user?.role === Role.BUYER;

  return (
    <AuthContext.Provider value={{ user, isAuthenticated, isAdmin, isSeller, isBuyer, login, logout, loading }}>
      {children}
    </AuthContext.Provider>
  );
};