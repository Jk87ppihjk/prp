import React from 'react';
import { Outlet } from 'react-router-dom';
import Header from '../components/Header';
import BuyerSidebar from '../components/BuyerSidebar';
import BottomNavBar from '../components/BottomNavBar';

const MainLayout: React.FC = () => {
  return (
    <div className="bg-slate-900 text-slate-200">
        <Header />
        <div className="flex">
            <BuyerSidebar />
            <div className="flex-1 md:ml-64">
                <main className="p-4 sm:p-6 md:p-8 pb-24 md:pb-8">
                    <Outlet />
                </main>
            </div>
            <BottomNavBar />
        </div>
    </div>
  );
};

export default MainLayout;
