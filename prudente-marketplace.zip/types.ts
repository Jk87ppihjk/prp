import { Role, ProductStatus, AttributeType } from './constants';

export interface User {
  id: string;
  fullName: string;
  email: string;
  cityId: string;
  role: Role;
  password?: string;
}

export interface Address {
  street: string;
  number: string;
  complement?: string;
  neighborhoodId: string;
  cityId: string;
  state: string;
  zipCode: string;
}

export interface Buyer extends User {
  shippingAddress?: Address;
}

export interface Seller extends User {
  homeAddress?: Address;
  storeId?: string;
}

export interface Admin extends User {}

export interface City {
  id: string;
  name: string;
}

export interface Neighborhood {
  id: string;
  name: string;
  cityId: string;
}

export interface Store {
  id: string;
  sellerId: string;
  name: string;
  bio: string;
  logoUrl: string;
  bannerUrl: string;
  categoryId: string;
  address: Address;
  cityId: string;
}

export interface Category {
  id: string;
  name: string;
  subcategories: Subcategory[];
}

export interface Subcategory {
  id: string;
  name: string;
  attributes: Attribute[];
}

export interface Attribute {
  id: string;
  name: string;
  type: AttributeType;
  options?: string[]; // For 'list' type
  required: boolean;
}

export interface Product {
  id: string;
  storeId: string;
  name: string;
  description: string;
  price: number;
  stock: number;
  categoryId: string;
  subcategoryId: string;
  attributes: Record<string, any>;
  images: string[];
  status: ProductStatus;
  rejectionReason?: string;
}

export interface FyVideo {
  id: string;
  sellerId: string;
  storeId: string;
  videoUrl: string; // Will be a data URL for mock
  caption: string;
  productId?: string;
  uploadDate: string;
}

// For enriching the FY video with details for the feed
export interface FyVideoWithDetails extends FyVideo {
  store: Store;
  product?: Product;
}

export interface CartItem extends Product {
  quantity: number;
}

export interface OrderItem {
  productId: string;
  storeId: string;
  productName: string;
  quantity: number;
  price: number; // price per item at time of purchase
}

export interface Order {
  id: string;
  buyerId: string;
  items: OrderItem[];
  totalPrice: number;
  date: string;
  shippingAddress: Address;
}