import {
  User,
  Address,
  Buyer,
  Seller,
  Admin,
  City,
  Neighborhood,
  Store,
  Category,
  Attribute,
  Product,
  Order,
  OrderItem,
  CartItem,
  FyVideo,
  FyVideoWithDetails,
} from '../types';
import { Role, ProductStatus, AttributeType } from '../constants';

// FIX: Define a type for the in-memory database to prevent TypeScript from inferring
// overly strict types, which caused issues with optional properties.
interface DB {
  users: (Admin | Buyer | Seller)[];
  cities: City[];
  neighborhoods: Neighborhood[];
  categories: Category[];
  stores: Store[];
  products: Product[];
  orders: Order[];
  fyVideos: FyVideo[];
}

// --- Helper Functions ---
const delay = (ms: number) => new Promise(res => setTimeout(res, ms));

const findUserByEmail = (email: string) => db.users.find(u => u.email.toLowerCase() === email.toLowerCase());

const findUserById = (id: string) => db.users.find(u => u.id === id);

// Security helper to remove password from user object
const omitPassword = (user: User | Admin | Buyer | Seller) => {
  const { password, ...userWithoutPassword } = user;
  return userWithoutPassword;
};

// --- In-memory Database ---
let db: DB = {
  users: [
    { id: 'admin-01', fullName: 'Admin Prudente', email: 'tutano172@gmail.com', password: '88178591', cityId: 'c1', role: Role.ADMIN } as Admin,
    { id: 'buyer-01', fullName: 'João Comprador', email: 'comprador@email.com', password: 'password123', cityId: 'c1', role: Role.BUYER, shippingAddress: { street: 'Rua do Comprador', number: '10', complement: 'Apto 1', neighborhoodId: 'n1', cityId: 'c1', state: 'SP', zipCode: '19000-001' } } as Buyer,
    { id: 'seller-01', fullName: 'Maria Vendedora', email: 'vendedor@email.com', password: 'password123', cityId: 'c1', role: Role.SELLER, homeAddress: undefined, storeId: 's1' } as Seller,
    { id: 'seller-02', fullName: 'Carlos Lojista', email: 'carlos@email.com', password: 'password123', cityId: 'c2', role: Role.SELLER, storeId: 's2' } as Seller,
    { id: 'seller-03', fullName: 'Ana Comerciante', email: 'ana@email.com', password: 'password123', cityId: 'c3', role: Role.SELLER, storeId: 's3' } as Seller,
    { id: 'seller-04', fullName: 'Pedro Mercador', email: 'pedro@email.com', password: 'password123', cityId: 'c4', role: Role.SELLER, storeId: 's4' } as Seller,
  ],
  cities: [
    { id: 'c1', name: 'Presidente Prudente' },
    { id: 'c2', name: 'Álvares Machado' },
    { id: 'c3', name: 'Marília' },
    { id: 'c4', name: 'Bauru' },
  ],
  neighborhoods: [
    { id: 'n1', name: 'Centro', cityId: 'c1' },
    { id: 'n2', name: 'Jd. Aviação', cityId: 'c1' },
    { id: 'n3', name: 'Centro', cityId: 'c2' },
    { id: 'n4', name: 'Centro', cityId: 'c3' },
    { id: 'n5', name: 'Centro', cityId: 'c4' },
  ],
  categories: [
    { 
      id: 'cat1', 
      name: 'Eletrônicos', 
      subcategories: [
        { 
          id: 'sub1', 
          name: 'Celulares', 
          attributes: [
            { id: 'attr1', name: 'Memória RAM', type: AttributeType.LIST, options: ['4GB', '8GB', '16GB'], required: true },
            { id: 'attr2', name: 'Armazenamento', type: AttributeType.TEXT, required: true },
            { id: 'attr3', name: 'Dual SIM', type: AttributeType.CHECKBOX, required: false },
          ] 
        },
        { id: 'sub2', name: 'Televisões', attributes: [] },
      ]
    },
    { id: 'cat2', name: 'Roupas', subcategories: [] },
    { id: 'cat3', name: 'Calçados', subcategories: [] },
    { id: 'cat4', name: 'Acessórios', subcategories: [] },
  ],
  stores: [
    { id: 's1', sellerId: 'seller-01', name: 'Loja da Maria', bio: 'Eletrônicos de ponta em Prudente!', logoUrl: 'https://picsum.photos/id/10/200', bannerUrl: 'https://picsum.photos/id/11/800/200', categoryId: 'cat1', cityId: 'c1', address: { street: 'Rua da Loja', number: '123', neighborhoodId: 'n1', cityId: 'c1', state: 'SP', zipCode: '19000-000' } },
    { id: 's2', sellerId: 'seller-02', name: 'Machado Modas', bio: 'As melhores roupas de Álvares Machado.', logoUrl: 'https://picsum.photos/id/20/200', bannerUrl: 'https://picsum.photos/id/21/800/200', categoryId: 'cat2', cityId: 'c2', address: { street: 'Av. Principal', number: '456', neighborhoodId: 'n3', cityId: 'c2', state: 'SP', zipCode: '19160-000' } },
    { id: 's3', sellerId: 'seller-03', name: 'Sapataria da Ana', bio: 'Calçados para toda a família em Marília.', logoUrl: 'https://picsum.photos/id/30/200', bannerUrl: 'https://picsum.photos/id/31/800/200', categoryId: 'cat3', cityId: 'c3', address: { street: 'R. das Botas', number: '789', neighborhoodId: 'n4', cityId: 'c3', state: 'SP', zipCode: '17500-000' } },
    { id: 's4', sellerId: 'seller-04', name: 'Acessórios do Pedro', bio: 'Tudo para complementar seu estilo em Bauru.', logoUrl: 'https://picsum.photos/id/40/200', bannerUrl: 'https://picsum.photos/id/41/800/200', categoryId: 'cat4', cityId: 'c4', address: { street: 'Travessa dos Brincos', number: '101', neighborhoodId: 'n5', cityId: 'c4', state: 'SP', zipCode: '17000-000' } },
  ],
  products: [
    // Store 1
    { id: 'p1', storeId: 's1', name: 'Smartphone XPTO', description: 'Ótimo celular', price: 1200, stock: 10, categoryId: 'cat1', subcategoryId: 'sub1', attributes: { 'Memória RAM': '8GB', 'Armazenamento': '128GB', 'Dual SIM': true }, images: ['https://picsum.photos/id/1/400/300'], status: ProductStatus.APPROVED, rejectionReason: ''},
    { id: 'p1a', storeId: 's1', name: 'Smart TV 50"', description: 'Imagem 4K', price: 2500, stock: 5, categoryId: 'cat1', subcategoryId: 'sub2', attributes: {}, images: ['https://picsum.photos/id/12/400/300'], status: ProductStatus.APPROVED, rejectionReason: ''},
    { id: 'p1b', storeId: 's1', name: 'Fone Bluetooth', description: 'Cancelamento de ruído', price: 350, stock: 30, categoryId: 'cat1', subcategoryId: 'sub1', attributes: {}, images: ['https://picsum.photos/id/13/400/300'], status: ProductStatus.APPROVED, rejectionReason: ''},
    { id: 'p1c', storeId: 's1', name: 'Notebook Gamer', description: 'Placa de vídeo dedicada', price: 5500, stock: 3, categoryId: 'cat1', subcategoryId: 'sub1', attributes: {}, images: ['https://picsum.photos/id/14/400/300'], status: ProductStatus.APPROVED, rejectionReason: ''},
    // Store 2
    { id: 'p2', storeId: 's2', name: 'Camiseta Básica', description: '100% Algodão', price: 50, stock: 100, categoryId: 'cat2', subcategoryId: '', attributes: {}, images: ['https://picsum.photos/id/22/400/300'], status: ProductStatus.APPROVED, rejectionReason: ''},
    { id: 'p2a', storeId: 's2', name: 'Calça Jeans', description: 'Modelo slim fit', price: 150, stock: 50, categoryId: 'cat2', subcategoryId: '', attributes: {}, images: ['https://picsum.photos/id/23/400/300'], status: ProductStatus.APPROVED, rejectionReason: ''},
    { id: 'p2b', storeId: 's2', name: 'Moletom com Capuz', description: 'Confortável e quente', price: 200, stock: 40, categoryId: 'cat2', subcategoryId: '', attributes: {}, images: ['https://picsum.photos/id/24/400/300'], status: ProductStatus.APPROVED, rejectionReason: ''},
    { id: 'p2c', storeId: 's2', name: 'Bermuda Tactel', description: 'Ideal para o verão', price: 70, stock: 80, categoryId: 'cat2', subcategoryId: '', attributes: {}, images: ['https://picsum.photos/id/25/400/300'], status: ProductStatus.APPROVED, rejectionReason: ''},
    // Store 3
    { id: 'p3', storeId: 's3', name: 'Tênis de Corrida', description: 'Leve e flexível', price: 300, stock: 25, categoryId: 'cat3', subcategoryId: '', attributes: {}, images: ['https://picsum.photos/id/32/400/300'], status: ProductStatus.APPROVED, rejectionReason: ''},
    { id: 'p3a', storeId: 's3', name: 'Sapato Social', description: 'Couro legítimo', price: 400, stock: 15, categoryId: 'cat3', subcategoryId: '', attributes: {}, images: ['https://picsum.photos/id/33/400/300'], status: ProductStatus.APPROVED, rejectionReason: ''},
    { id: 'p3b', storeId: 's3', name: 'Sandália Rasteira', description: 'Conforto para o dia a dia', price: 90, stock: 60, categoryId: 'cat3', subcategoryId: '', attributes: {}, images: ['https://picsum.photos/id/34/400/300'], status: ProductStatus.APPROVED, rejectionReason: ''},
    { id: 'p3c', storeId: 's3', name: 'Bota de Inverno', description: 'Forrada e resistente', price: 350, stock: 20, categoryId: 'cat3', subcategoryId: '', attributes: {}, images: ['https://picsum.photos/id/35/400/300'], status: ProductStatus.APPROVED, rejectionReason: ''},
    // Store 4
    { id: 'p4', storeId: 's4', name: 'Relógio de Pulso', description: 'Design moderno', price: 250, stock: 30, categoryId: 'cat4', subcategoryId: '', attributes: {}, images: ['https://picsum.photos/id/42/400/300'], status: ProductStatus.APPROVED, rejectionReason: ''},
    { id: 'p4a', storeId: 's4', name: 'Óculos de Sol', description: 'Proteção UV400', price: 180, stock: 40, categoryId: 'cat4', subcategoryId: '', attributes: {}, images: ['https://picsum.photos/id/43/400/300'], status: ProductStatus.APPROVED, rejectionReason: ''},
    { id: 'p4b', storeId: 's4', name: 'Cinto de Couro', description: 'Fivela de metal', price: 120, stock: 50, categoryId: 'cat4', subcategoryId: '', attributes: {}, images: ['https://picsum.photos/id/44/400/300'], status: ProductStatus.APPROVED, rejectionReason: ''},
    { id: 'p4c', storeId: 's4', name: 'Bolsa Feminina', description: 'Espaçosa e elegante', price: 280, stock: 25, categoryId: 'cat4', subcategoryId: '', attributes: {}, images: ['https://picsum.photos/id/45/400/300'], status: ProductStatus.APPROVED, rejectionReason: ''},
    // Pending product
    { id: 'p-pending', storeId: 's1', name: 'Produto Pendente', description: 'Aguardando aprovação', price: 99, stock: 10, categoryId: 'cat2', subcategoryId: '', attributes: {}, images: ['https://picsum.photos/id/99/400/300'], status: ProductStatus.PENDING, rejectionReason: ''},
  ],
  orders: [],
  fyVideos: [
    { id: 'fy1', sellerId: 'seller-01', storeId: 's1', videoUrl: 'https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4', caption: 'Confira nosso novo Smartphone XPTO! A melhor tecnologia na sua mão.', productId: 'p1', uploadDate: new Date().toISOString() },
    { id: 'fy2', sellerId: 'seller-02', storeId: 's2', videoUrl: 'https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4', caption: 'Chegou a nova coleção de camisetas. 100% algodão e muito estilo!', productId: 'p2', uploadDate: new Date().toISOString() },
    { id: 'fy3', sellerId: 'seller-03', storeId: 's3', videoUrl: 'https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerMeltdowns.mp4', caption: 'Corra com mais conforto com nossos novos tênis!', productId: 'p3', uploadDate: new Date().toISOString() },
  ],
};

// --- Mock API Implementation ---
export const api = {
  // --- Auth ---
  login: async (email: string, pass: string): Promise<User> => {
    await delay(500);
    const user = findUserByEmail(email);
    if (user && user.password === pass) {
      localStorage.setItem('userId', user.id);
      return omitPassword(user) as User;
    }
    throw new Error('Credenciais inválidas.');
  },

  logout: () => {
    localStorage.removeItem('userId');
  },
  
  checkSession: async (): Promise<User | null> => {
    await delay(200);
    const userId = localStorage.getItem('userId');
    if (!userId) return null;
    const user = findUserById(userId);
    return user ? omitPassword(user) as User : null;
  },

  register: async (userData: Omit<User, 'id'>): Promise<User> => {
    await delay(500);
    if (findUserByEmail(userData.email)) {
      throw new Error('Este email já está em uso.');
    }
    const newUser = { ...userData, id: `user-${Date.now()}` };
    db.users.push(newUser);
    return omitPassword(newUser) as User;
  },

  // --- User Details ---
  getBuyerDetails: async(userId: string): Promise<Buyer> => {
    await delay(300);
    const user = findUserById(userId);
    if (!user || user.role !== Role.BUYER) throw new Error("Comprador não encontrado");
    return omitPassword(user) as Buyer;
  },
  
  getSellerDetails: async(userId: string): Promise<Seller> => {
    await delay(300);
    const user = findUserById(userId);
    if (!user || user.role !== Role.SELLER) throw new Error("Vendedor não encontrado");
    return omitPassword(user) as Seller;
  },

  saveBuyerAddress: async(userId: string, address: Address): Promise<void> => {
    await delay(400);
    const userIndex = db.users.findIndex(u => u.id === userId && u.role === Role.BUYER);
    if (userIndex > -1) {
        (db.users[userIndex] as Buyer).shippingAddress = address;
    }
  },

  saveSellerHomeAddress: async(userId: string, address: Address): Promise<void> => {
    await delay(400);
    const userIndex = db.users.findIndex(u => u.id === userId && u.role === Role.SELLER);
    if (userIndex > -1) {
        (db.users[userIndex] as Seller).homeAddress = address;
    }
  },

  // --- Locations ---
  getCities: async (): Promise<City[]> => {
    await delay(100);
    return [...db.cities];
  },
  addCity: async (name: string): Promise<City> => {
    await delay(200);
    const newCity = { id: `c-${Date.now()}`, name };
    db.cities.push(newCity);
    return newCity;
  },
  getNeighborhoodsByCity: async (cityId: string): Promise<Neighborhood[]> => {
    await delay(100);
    return db.neighborhoods.filter(n => n.cityId === cityId);
  },
  addNeighborhood: async (cityId: string, name: string): Promise<Neighborhood> => {
    await delay(200);
    const newNeighborhood = { id: `n-${Date.now()}`, name, cityId };
    db.neighborhoods.push(newNeighborhood);
    return newNeighborhood;
  },

  // --- Categories ---
  getCategories: async(): Promise<Category[]> => {
    await delay(200);
    return JSON.parse(JSON.stringify(db.categories));
  },
  addCategory: async(name: string): Promise<Category> => {
    await delay(300);
    const newCategory = { id: `cat-${Date.now()}`, name, subcategories: [] };
    db.categories.push(newCategory);
    return newCategory;
  },
  addSubcategory: async(categoryId: string, name: string): Promise<void> => {
    await delay(300);
    const category = db.categories.find(c => c.id === categoryId);
    if (category) {
        category.subcategories.push({ id: `sub-${Date.now()}`, name, attributes: [] });
    }
  },
  addAttribute: async(categoryId: string, subcategoryId: string, attribute: Omit<Attribute, 'id'>): Promise<void> => {
     await delay(300);
     const category = db.categories.find(c => c.id === categoryId);
     const subcategory = category?.subcategories.find(s => s.id === subcategoryId);
     if (subcategory) {
        subcategory.attributes.push({ ...attribute, id: `attr-${Date.now()}` });
     }
  },

  // --- Store ---
  getStoreById: async (storeId: string): Promise<Store | null> => {
    await delay(200);
    const store = db.stores.find(s => s.id === storeId);
    return store ? { ...store } : null;
  },
  getStoresByCityId: async (cityId: string): Promise<Store[]> => {
    await delay(300);
    return db.stores.filter(s => s.cityId === cityId);
  },
  getStoreBySellerId: async(sellerId: string): Promise<Store | null> => {
    await delay(300);
    const store = db.stores.find(s => s.sellerId === sellerId);
    return store ? { ...store } : null;
  },
  saveStore: async(storeData: Store): Promise<Store> => {
    await delay(500);
    const storeIndex = db.stores.findIndex(s => s.id === storeData.id || s.sellerId === storeData.sellerId);
    if (storeIndex > -1) {
        db.stores[storeIndex] = { ...db.stores[storeIndex], ...storeData };
        return db.stores[storeIndex];
    } else {
        const newStore = { ...storeData, id: `s-${Date.now()}` };
        db.stores.push(newStore);
        const userIndex = db.users.findIndex(u => u.id === storeData.sellerId);
        if (userIndex > -1) (db.users[userIndex] as Seller).storeId = newStore.id;
        return newStore;
    }
  },

  // --- Products ---
  getApprovedProducts: async(): Promise<Product[]> => {
    await delay(400);
    return db.products.filter(p => p.status === ProductStatus.APPROVED);
  },
  getApprovedProductsByCityId: async (cityId: string): Promise<Product[]> => {
    await delay(400);
    const storesInCity = db.stores.filter(s => s.cityId === cityId).map(s => s.id);
    return db.products.filter(p => p.status === ProductStatus.APPROVED && storesInCity.includes(p.storeId));
  },
  getApprovedProductsByStoreId: async (storeId: string): Promise<Product[]> => {
    await delay(300);
    return db.products.filter(p => p.storeId === storeId && p.status === ProductStatus.APPROVED);
  },
  getProductsByStatus: async(status: ProductStatus): Promise<Product[]> => {
    await delay(300);
    return db.products.filter(p => p.status === status);
  },
  getProductsBySellerId: async(sellerId: string): Promise<Product[]> => {
    await delay(300);
    const store = db.stores.find(s => s.sellerId === sellerId);
    if (!store) return [];
    return db.products.filter(p => p.storeId === store.id);
  },
  addProduct: async(productData: Omit<Product, 'id' | 'status'>): Promise<Product> => {
    await delay(500);
    const newProduct: Product = {
        ...productData,
        id: `p-${Date.now()}`,
        status: ProductStatus.PENDING,
        images: ['https://picsum.photos/400/300'] // Mock image
    };
    db.products.push(newProduct);
    return newProduct;
  },
  approveProduct: async(productId: string): Promise<void> => {
    await delay(200);
    const product = db.products.find(p => p.id === productId);
    if (product) product.status = ProductStatus.APPROVED;
  },
  rejectProduct: async(productId: string, reason: string): Promise<void> => {
    await delay(200);
    const product = db.products.find(p => p.id === productId);
    if (product) {
        product.status = ProductStatus.REJECTED;
        product.rejectionReason = reason;
    }
  },

  // --- FY Videos ---
  addFyVideo: async(videoData: Omit<FyVideo, 'id' | 'uploadDate'>): Promise<FyVideo> => {
    await delay(600);
    const newVideo = {
      ...videoData,
      id: `fy-${Date.now()}`,
      uploadDate: new Date().toISOString(),
    };
    db.fyVideos.unshift(newVideo);
    return newVideo;
  },
  getFyVideosBySellerId: async(sellerId: string): Promise<FyVideo[]> => {
    await delay(400);
    return db.fyVideos.filter(v => v.sellerId === sellerId).sort((a,b) => new Date(b.uploadDate).getTime() - new Date(a.uploadDate).getTime());
  },
  deleteFyVideo: async(videoId: string): Promise<void> => {
    await delay(300);
    db.fyVideos = db.fyVideos.filter(v => v.id !== videoId);
  },
  getAllFyVideosWithDetails: async(): Promise<FyVideoWithDetails[]> => {
    await delay(500);
    const enrichedVideos = db.fyVideos.map(video => {
      const store = db.stores.find(s => s.id === video.storeId);
      const product = db.products.find(p => p.id === video.productId);
      return { ...video, store, product };
    }).filter(v => v.store); // Only return videos where the store still exists
    return (enrichedVideos as FyVideoWithDetails[]).sort((a,b) => new Date(b.uploadDate).getTime() - new Date(a.uploadDate).getTime());
  },

  // --- Orders ---
  placeOrder: async (buyerId: string, items: CartItem[], shippingAddress: Address): Promise<Order> => {
    await delay(700);
    
    // Validate stock
    for (const item of items) {
      const productInDb = db.products.find(p => p.id === item.id);
      if (!productInDb || productInDb.stock < item.quantity) {
        throw new Error(`Estoque insuficiente para o produto: ${item.name}`);
      }
    }

    // Decrement stock
    items.forEach(item => {
      const productInDb = db.products.find(p => p.id === item.id);
      if (productInDb) {
        productInDb.stock -= item.quantity;
      }
    });

    const orderItems: OrderItem[] = items.map(item => ({
      productId: item.id,
      storeId: item.storeId,
      productName: item.name,
      quantity: item.quantity,
      price: item.price,
    }));

    const totalPrice = items.reduce((total, item) => total + item.price * item.quantity, 0);

    const newOrder: Order = {
      id: `order-${Date.now()}`,
      buyerId,
      items: orderItems,
      totalPrice,
      date: new Date().toISOString(),
      shippingAddress,
    };

    db.orders.push(newOrder);
    return newOrder;
  },

  getOrdersByBuyerId: async (buyerId: string): Promise<Order[]> => {
    await delay(300);
    return db.orders.filter(order => order.buyerId === buyerId).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  },

  getOrdersByStoreId: async (storeId: string): Promise<Order[]> => {
    await delay(300);
    const storeOrders = db.orders.filter(order => 
      order.items.some(item => item.storeId === storeId)
    );

    // Return orders but only with items relevant to the store
    return storeOrders.map(order => ({
      ...order,
      items: order.items.filter(item => item.storeId === storeId)
    })).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  },
};