
import express from 'express';
import { TransactionalEmailsApi, SendSmtpEmail, TransactionalEmailsApiApiKeys } from '@getbrevo/brevo';
import dotenv from 'dotenv';
import cors from 'cors';
import mysql from 'mysql2/promise';
import { v2 as cloudinary } from 'cloudinary';
import { randomUUID } from 'crypto';
import jwt from 'jsonwebtoken';


// Load environment variables from .env file
dotenv.config();

const app = express();
const port = process.env.PORT || 3001;

// --- Middleware ---
// Enable CORS for all routes
app.use(cors());
// Parse JSON bodies for POST requests
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));


// --- Service Connections & Configurations ---

// 1. MySQL Database Connection Pool
let dbPool;
try {
  dbPool = mysql.createPool({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
  });
  
  // Test the connection
  const connection = await dbPool.getConnection();
  console.log('Successfully connected to the MySQL database.');
  connection.release(); // release the connection back to the pool
} catch (error) {
  console.error('Error connecting to MySQL database:', error.message);
  // Exit the process if the database connection fails, as the app can't run without it.
  process.exit(1); 
}


// 2. Cloudinary API Configuration
try {
    if (!process.env.CLOUDINARY_CLOUD_NAME || !process.env.CLOUDINARY_API_KEY || !process.env.CLOUDINARY_API_SECRET) {
        throw new Error('Missing Cloudinary environment variables.');
    }
    cloudinary.config({
      cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
      api_key: process.env.CLOUDINARY_API_KEY,
      api_secret: process.env.CLOUDINARY_API_SECRET,
      secure: true,
    });
    console.log('Cloudinary SDK configured successfully.');
} catch (error) {
    console.error('Error configuring Cloudinary:', error.message);
}


// 3. JWT Secret Configuration
const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) {
  console.error('FATAL ERROR: JWT_SECRET environment variable is not set.');
  process.exit(1); 
} else {
  console.log('JWT Secret has been configured.');
}


// 4. Brevo API Client Setup
const brevoApiKey = process.env.BREVO_API_KEY;
const brevoSenderEmail = process.env.BREVO_SENDER_EMAIL;
let apiInstance; // This will hold the Brevo API instance.

if (brevoApiKey && brevoSenderEmail) {
    try {
        apiInstance = new TransactionalEmailsApi();
        apiInstance.setApiKey(TransactionalEmailsApiApiKeys.apiKey, brevoApiKey);
        console.log('Brevo Transactional API configured successfully.');
    } catch (error) {
        console.error('Error configuring Brevo API:', error.message);
    }
} else {
    console.warn('BREVO_API_KEY or BREVO_SENDER_EMAIL environment variable not set. Email functionality will be disabled.');
}

// --- Helper Functions ---
async function sendVerificationEmail(toEmail, code) {
    if (!apiInstance) {
      throw new Error("Email service is not configured.");
    }
    const sendSmtpEmail = new SendSmtpEmail();
    sendSmtpEmail.sender = { email: brevoSenderEmail, name: 'Prudente Marketplace' };
    sendSmtpEmail.to = [{ email: toEmail }];
    sendSmtpEmail.subject = 'Seu código de verificação - Prudente Marketplace';
    sendSmtpEmail.htmlContent = `
      <h1>Bem-vindo ao Prudente Marketplace!</h1>
      <p>Seu código de verificação é: <strong>${code}</strong></p>
      <p>Use este código para ativar sua conta.</p>
    `;
    await apiInstance.sendTransacEmail(sendSmtpEmail);
}

async function sendPasswordResetEmail(toEmail, code) {
    if (!apiInstance) {
        throw new Error("Email service is not configured.");
    }
    const sendSmtpEmail = new SendSmtpEmail();
    sendSmtpEmail.sender = { email: brevoSenderEmail, name: 'Prudente Marketplace' };
    sendSmtpEmail.to = [{ email: toEmail }];
    sendSmtpEmail.subject = 'Redefinição de Senha - Prudente Marketplace';
    sendSmtpEmail.htmlContent = `
        <h1>Redefinição de Senha</h1>
        <p>Você solicitou a redefinição da sua senha.</p>
        <p>Seu código de redefinição é: <strong>${code}</strong></p>
        <p>Este código expira em 1 hora. Se você não solicitou isso, por favor, ignore este e-mail.</p>
    `;
    await apiInstance.sendTransacEmail(sendSmtpEmail);
}


// --- Routes ---

/**
 * Health check endpoint
 */
app.get('/', (req, res) => {
  res.status(200).json({ message: 'Prudente Marketplace Backend is running.' });
});

/**
 * POST /api/register
 * Registers a new user, saves them to DB with a verification code, and sends the code via email.
 */
app.post('/api/register', async (req, res) => {
    const { fullName, email, password, cityId, role } = req.body;
    if (!fullName || !email || !password || !cityId || !role) {
        return res.status(400).json({ message: 'Todos os campos são obrigatórios.' });
    }

    // WARNING: In a production environment, ALWAYS hash passwords.
    // Example using bcrypt: const hashedPassword = await bcrypt.hash(password, 10);
    const hashedPassword = password; // Storing plaintext for now, as per current setup.
    const verificationCode = Math.floor(1000 + Math.random() * 9000).toString();
    const userId = `user-${randomUUID()}`;

    let connection;
    try {
        connection = await dbPool.getConnection();
        
        // Check if email already exists
        const [existingUsers] = await connection.query('SELECT id FROM users WHERE email = ?', [email]);
        if (existingUsers.length > 0) {
            return res.status(409).json({ message: 'Este e-mail já está em uso.' });
        }

        // Insert new user
        await connection.query(
            'INSERT INTO users (id, fullName, email, password, cityId, role, verificationCode) VALUES (?, ?, ?, ?, ?, ?, ?)',
            [userId, fullName, email, hashedPassword, cityId, role, verificationCode]
        );

        // Send verification email
        await sendVerificationEmail(email, verificationCode);

        res.status(201).json({ message: 'Cadastro realizado com sucesso! Verifique seu e-mail para ativar a conta.' });

    } catch (error) {
        console.error('Erro no registro:', error);
        res.status(500).json({ message: 'Erro interno do servidor ao tentar registrar.' });
    } finally {
        if (connection) connection.release();
    }
});

/**
 * POST /api/verify
 * Verifies a user's account using the provided code.
 */
app.post('/api/verify', async (req, res) => {
    const { email, code } = req.body;
    if (!email || !code) {
        return res.status(400).json({ message: 'E-mail e código são obrigatórios.' });
    }

    let connection;
    try {
        connection = await dbPool.getConnection();
        const [users] = await connection.query('SELECT id, verificationCode FROM users WHERE email = ? AND isVerified = FALSE', [email]);
        
        if (users.length === 0) {
            return res.status(404).json({ message: 'Usuário não encontrado ou já verificado.' });
        }

        const user = users[0];
        if (user.verificationCode !== code) {
            return res.status(400).json({ message: 'Código de verificação inválido.' });
        }

        // Update user to verified status
        await connection.query('UPDATE users SET isVerified = TRUE, verificationCode = NULL WHERE id = ?', [user.id]);

        res.status(200).json({ message: 'E-mail verificado com sucesso! Você já pode fazer login.' });

    } catch (error) {
        console.error('Erro na verificação:', error);
        res.status(500).json({ message: 'Erro interno do servidor ao tentar verificar.' });
    } finally {
        if (connection) connection.release();
    }
});

/**
 * POST /api/login
 * Logs a user in, checking if their account is verified.
 */
app.post('/api/login', async (req, res) => {
    const { email, password } = req.body;
    if (!email || !password) {
        return res.status(400).json({ message: 'E-mail e senha são obrigatórios.' });
    }

    let connection;
    try {
        connection = await dbPool.getConnection();
        const [users] = await connection.query('SELECT * FROM users WHERE email = ?', [email]);

        if (users.length === 0) {
            return res.status(401).json({ message: 'Credenciais inválidas.' });
        }

        const user = users[0];
        // WARNING: In production, compare hashed passwords.
        // const isMatch = await bcrypt.compare(password, user.password);
        if (password !== user.password) { // Plaintext comparison
             return res.status(401).json({ message: 'Credenciais inválidas.' });
        }

        if (!user.isVerified) {
            return res.status(403).json({ message: 'Sua conta ainda não foi verificada. Por favor, verifique seu e-mail.' });
        }
        
        // User is authenticated and verified, create JWT
        const { password: _, ...userPayload } = user; // remove password from payload
        const token = jwt.sign(userPayload, JWT_SECRET, { expiresIn: '1d' });

        res.status(200).json({ token, user: userPayload });

    } catch (error) {
        console.error('Erro no login:', error);
        res.status(500).json({ message: 'Erro interno do servidor ao tentar fazer login.' });
    } finally {
        if (connection) connection.release();
    }
});

/**
 * POST /api/forgot-password
 * Sends a password reset code to the user's email.
 */
app.post('/api/forgot-password', async (req, res) => {
    const { email } = req.body;
    if (!email) {
        return res.status(400).json({ message: 'O e-mail é obrigatório.' });
    }

    let connection;
    try {
        connection = await dbPool.getConnection();
        const [users] = await connection.query('SELECT id FROM users WHERE email = ?', [email]);

        // To prevent user enumeration, always send a success-like response.
        // The action (sending email) only happens if the user exists.
        if (users.length > 0) {
            const user = users[0];
            const resetCode = Math.floor(100000 + Math.random() * 900000).toString(); // 6-digit code
            const resetCodeExpires = new Date(Date.now() + 3600000); // Expires in 1 hour

            await connection.query(
                'UPDATE users SET resetCode = ?, resetCodeExpires = ? WHERE id = ?',
                [resetCode, resetCodeExpires, user.id]
            );

            await sendPasswordResetEmail(email, resetCode);
        }

        res.status(200).json({ message: 'Se um usuário com este e-mail existir, um código de redefinição foi enviado.' });

    } catch (error) {
        console.error('Erro no forgot-password:', error);
        res.status(500).json({ message: 'Erro interno do servidor.' });
    } finally {
        if (connection) connection.release();
    }
});


/**
 * POST /api/reset-password
 * Resets the user's password using the provided code.
 */
app.post('/api/reset-password', async (req, res) => {
    const { email, code, newPassword } = req.body;
    if (!email || !code || !newPassword) {
        return res.status(400).json({ message: 'Todos os campos são obrigatórios.' });
    }
    
    // WARNING: Store hashed password in production
    const hashedPassword = newPassword;

    let connection;
    try {
        connection = await dbPool.getConnection();
        const [users] = await connection.query(
            'SELECT id FROM users WHERE email = ? AND resetCode = ? AND resetCodeExpires > NOW()',
            [email, code]
        );

        if (users.length === 0) {
            return res.status(400).json({ message: 'Código inválido ou expirado.' });
        }

        const user = users[0];
        await connection.query(
            'UPDATE users SET password = ?, resetCode = NULL, resetCodeExpires = NULL WHERE id = ?',
            [hashedPassword, user.id]
        );

        res.status(200).json({ message: 'Senha redefinida com sucesso!' });

    } catch (error) {
        console.error('Erro no reset-password:', error);
        res.status(500).json({ message: 'Erro interno do servidor.' });
    } finally {
        if (connection) connection.release();
    }
});


// --- Start Server ---
app.listen(port, () => {
  console.log(`Backend server listening on http://localhost:${port}`);
});

// Export the database pool for use in other modules
export { dbPool };