
export enum Role {
  BUYER = 'BUYER',
  SELLER = 'SELLER',
  ADMIN = 'ADMIN',
}

export enum ProductStatus {
  PENDING = 'PENDENTE',
  APPROVED = 'APROVADO',
  REJECTED = 'REJEITADO',
}

export enum AttributeType {
  TEXT = 'TEXT',
  CHECKBOX = 'CHECKBOX',
  LIST = 'LIST',
}
