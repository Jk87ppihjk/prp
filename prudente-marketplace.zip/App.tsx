import React from 'react';
import { HashRouter, Routes, Route, Navigate, Outlet } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { useAuth } from './hooks/useAuth';
import LoginScreen from './screens/LoginScreen';
import RegisterScreen from './screens/RegisterScreen';
import VerifyEmailScreen from './screens/VerifyEmailScreen';
import ForgotPasswordScreen from './screens/ForgotPasswordScreen'; // Import new screen
import ResetPasswordScreen from './screens/ResetPasswordScreen'; // Import new screen
import BuyerDashboard from './screens/BuyerDashboard';
import BuyerProfile from './screens/BuyerProfile';
import SellerDashboard from './screens/SellerDashboard';
import AdminDashboard from './screens/AdminDashboard';
import NotFound from './screens/NotFound';
import Header from './components/Header';
import StorePage from './screens/StorePage';
import { CartProvider } from './context/CartContext';
import CartScreen from './screens/CartScreen';
import CheckoutScreen from './screens/CheckoutScreen';
import OrderSuccessScreen from './screens/OrderSuccessScreen';
import MainLayout from './layouts/MainLayout';
import ForYouScreen from './screens/ForYouScreen';
import SellerFyManagement from './screens/seller/SellerFyManagement';

const App: React.FC = () => {
  return (
    <AuthProvider>
      <CartProvider>
        <HashRouter>
          <AppRoutes />
        </HashRouter>
      </CartProvider>
    </AuthProvider>
  );
};

const AppRoutes: React.FC = () => {
    const { isAuthenticated, isBuyer, isSeller, isAdmin, loading } = useAuth();
  
    if (loading) {
      return <div className="flex justify-center items-center h-screen"><div className="animate-spin rounded-full h-32 w-32 border-t-2 border-b-2 border-sky-400"></div></div>;
    }
  
    return (
      <Routes>
        <Route path="/login" element={!isAuthenticated ? <LoginScreen /> : <Navigate to="/" />} />
        <Route path="/register" element={!isAuthenticated ? <RegisterScreen /> : <Navigate to="/" />} />
        <Route path="/verify-email" element={!isAuthenticated ? <VerifyEmailScreen /> : <Navigate to="/" />} />
        <Route path="/forgot-password" element={!isAuthenticated ? <ForgotPasswordScreen /> : <Navigate to="/" />} />
        <Route path="/reset-password" element={!isAuthenticated ? <ResetPasswordScreen /> : <Navigate to="/" />} />
        
        <Route path="/" element={
            isAuthenticated ? (
                isBuyer ? <Navigate to="/dashboard" /> :
                isSeller ? <Navigate to="/seller" /> :
                isAdmin ? <Navigate to="/admin" /> :
                <NotFound />
            ) : <Navigate to="/login" />
        }/>

        {/* Buyer Routes with Main Layout */}
        <Route element={
            <ProtectedRoute isAllowed={isAuthenticated && isBuyer}>
                <MainLayout />
            </ProtectedRoute>
        }>
            <Route path="/dashboard" element={<BuyerDashboard />} />
            <Route path="/foryou" element={<ForYouScreen />} />
            <Route path="/profile" element={<BuyerProfile />} />
            <Route path="/store/:storeId" element={<StorePage />} />
            <Route path="/cart" element={<CartScreen />} />
            <Route path="/checkout" element={<CheckoutScreen />} />
            <Route path="/order-success" element={<OrderSuccessScreen />} />
        </Route>
        
        {/* Seller & Admin Routes */}
        <Route path="/seller/*" element={
            <ProtectedRoute isAllowed={isAuthenticated && isSeller}>
                <SellerDashboard />
            </ProtectedRoute>
        }/>
        <Route path="/admin/*" element={
            <ProtectedRoute isAllowed={isAuthenticated && isAdmin}>
                <AdminDashboard />
            </ProtectedRoute>
        }/>

        <Route path="*" element={<NotFound />} />
      </Routes>
    );
  };
  
  const ProtectedRoute: React.FC<{ isAllowed: boolean; children: React.ReactElement }> = ({ isAllowed, children }) => {
    if (!isAllowed) {
      return <Navigate to="/login" replace />;
    }
    return children;
  };
  
export default App;